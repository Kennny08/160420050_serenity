

<?php $__env->startSection('admincontent'); ?>
    <div class="page-title-box">

    </div>
    <!-- end page-title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h3 class="mt-0 header-title">Rekomendasi Produk</h3>
                    <p class="sub-title">
                    </p>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible" role="alert">
                            <button type="button" class="close text-danger" data-dismiss="alert" aria-label="Close">
                                <span class="text-danger" aria-hidden="true">&times;</span>
                            </button>
                            <p class="mb-0"><strong>Maaf, terjadi kesalahan!</strong></p>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="mt-0 mb-1">- <?php echo e($error); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('admin.prosesrekomendasiproduk')); ?>"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group col-md-12">
                            
                        </div>

                        <?php if($keterangan == 'Berhasil'): ?>
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label for="exampleInputEmail1"><strong>Tanggal Mulai Riwayat Penjualan</strong></label>
                                    <input type="date" class="form-control" name="tanggalMulai" min="<?php echo e($tanggalMulai); ?>"
                                        max="<?php echo e($tanggalAkhir); ?>" id="tanggalMulaiPenjualan" aria-describedby="emailHelp"
                                        placeholder="Silahkan Pilih Tanggal Reservasi" required>
                                    <small id="emailHelp" class="form-text text-muted">Pilih Tanggal Mulai Riwayat
                                        Penjualan Anda
                                        disini!</small>

                                </div>

                                <div class="col-md-6">
                                    <label for="exampleInputEmail1"><strong>Tanggal Akhir Riwayat Penjualan</strong></label>
                                    <input type="date" class="form-control" name="tanggalAkhir" min="<?php echo e($tanggalMulai); ?>"
                                        max="<?php echo e($tanggalAkhir); ?>" id="tanggalAkhirPenjualan" aria-describedby="emailHelp"
                                        placeholder="Silahkan Pilih Tanggal Reservasi" required>
                                    <small id="emailHelp" class="form-text text-muted">Pilih Tanggal Akhir Riwayat Penjualan
                                        Anda
                                        disini!</small>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label for="exampleInputEmail1"><strong>Minimum Support (min 1)</strong></label>
                                    <input type="number" class="form-control" name="minSupport" min="1"
                                        id="txtMinimumSupport" aria-describedby="emailHelp" value="1"
                                        placeholder="nilai support" required>
                                    <small id="emailHelp" class="form-text text-muted">Masukkan nilai Minimum Support
                                        disini!</small>

                                </div>

                                <div class="col-md-6">
                                    <label for="exampleInputEmail1"><strong>Minimum Confidence(%)</strong></label>
                                    <input type="number" class="form-control" name="minConfidence" min="1"
                                        max="100" id="txtMinimumConfidence" aria-describedby="emailHelp" value="1"
                                        placeholder="minimum confidence" required>
                                    <small id="emailHelp" class="form-text text-muted">Masukkan nilai Minimum Confidence
                                        disini!</small>
                                </div>
                            </div>

                            <div class="form-group text-right">
                                <button id="tesbutton" style="width: 200px" type="submit"
                                    class="btn btn-primary btn-lg waves-effect waves-light">Konfirmasi</button>
                            </div>

                            <?php if(isset($freqItemSets) && isset($assocRules)): ?>
                                <div class="card shadow">
                                    <div class="card-body">
                                        <div class="form-group row text-center mt-3">
                                            <div class="form-group col-md-12">
                                                <h5><?php echo e($titleTabel); ?></h5>
                                            </div>
                                        </div>
                                        <div class="form-group row text-center mt-3">
                                            <div class="form-group col-md-12">
                                                <table class="table table-bordered">
                                                    <thead class="thead-default">
                                                        <tr class="text-center">
                                                            <th>Nama Perawatan / Produk</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $freqItemSets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($fis); ?></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                                <br>
                                                <table class="table table-bordered">
                                                    <thead class="thead-default">
                                                        <tr class="text-center">
                                                            <th>Kombinasi Perawatan atau Produk</th>
                                                            <th>Confidence</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $assocRules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar => $ar1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php $__currentLoopData = $ar1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar2 => $ar3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><span style="font-size: 15px"
                                                                            class="font-weight-bold">jika ingin mempromosikan </span>
                                                                        <?php echo e($ar); ?> <span style="font-size: 15px"
                                                                            class="font-weight-bold">maka dapat dipasangkan dengan </span>
                                                                        <?php echo e($ar2); ?>

                                                                    </td>
                                                                    <td><?php echo e($ar3); ?>%</td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>


                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="col-xl-12">
                                <div class="card text-white bg-danger text-center">
                                    <div class="card-body">
                                        <blockquote class="card-bodyquote mb-0">
                                            <h2>Belum terdapat penjualan yang memiliki status selesai</h2>
                                            <footer class=" text-white font-12">
                                                <h6>Silahkan menunggu hingga terdapat penjualan atau reservasi yang telah
                                                    diselesaikan!</h6>
                                            </footer>
                                        </blockquote>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                    </form>


                </div>
            </div>
        </div>
        <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\salon_ta\serenity\resources\views/admin/rekomendasiproduk/settingrekomendasiproduk.blade.php ENDPATH**/ ?>