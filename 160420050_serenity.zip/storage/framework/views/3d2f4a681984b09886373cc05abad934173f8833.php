

<?php $__env->startSection('title', 'Admin || Edit Produk'); ?>

<?php $__env->startSection('admincontent'); ?>
    <div class="page-title-box">

    </div>
    <!-- end page-title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h3 class="mt-0 header-title">Edit Produk</h3>
                    <p class="sub-title">
                    </p>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible" role="alert">
                            <button type="button" class="close text-danger" data-dismiss="alert" aria-label="Close">
                                <span class="text-danger" aria-hidden="true">&times;</span>
                            </button>
                            <p class="mb-0"><strong>Maaf, terjadi kesalahan!</strong></p>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="mt-0 mb-1">- <?php echo e($error); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    <form id="formUpdateProduk" method="POST" action="<?php echo e(route('produks.update', $produk->id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group col-md-12">
                        </div>

                        <div class="form-group row">
                            <div class="col-md-12">
                                <label for="exampleInputEmail1"><strong>Nama Produk</strong></label>
                                <input type="text" class="form-control" name="namaProduk" id="txtNamaProduk"
                                    aria-describedby="emailHelp" placeholder="Silahkan masukkan nama produk" required
                                    value="<?php echo e($produk->nama); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukkan nama produk disini!</small>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-4">
                                <label for="exampleInputEmail1"><strong>Kode Produk</strong></label>
                                <input type="text" class="form-control" name="kode_produk" id="txtKodeProduk"
                                    aria-describedby="emailHelp" placeholder="Silahkan masukkan kode produk" required
                                    value="<?php echo e($produk->kode_produk); ?>" readonly>
                                <small id="emailHelp" class="form-text text-muted">Kode produk!</small>
                            </div>
                            <div class="col-md-4">
                                <label for="exampleInputEmail1"><strong>Harga Jual Produk</strong></label>
                                <input type="number" class="form-control" name="hargaJual" id="numHargaJual" min="1"
                                    aria-describedby="emailHelp" placeholder="Silahkan masukkan harga jual produk" required
                                    value="<?php echo e($produk->harga_jual); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukkan harga jual produk
                                    disini!</small>
                            </div>
                            <div class="col-md-4">
                                <label for="exampleInputEmail1"><strong>Harga Beli Produk</strong></label>
                                <input type="number" class="form-control" name="hargaBeli" id="numHargaBeli" min="1"
                                    aria-describedby="emailHelp" placeholder="Silahkan masukkan harga beli produk" required
                                    value="<?php echo e($produk->harga_beli); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukkan harga beli produk
                                    disini!</small>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-12">
                                <label for="exampleInputEmail1"><strong>Deskripsi Produk</strong></label>
                                <textarea aria-describedby="emailHelp" class="form-control" name="deskripsiProduk" id="" cols="30"
                                    rows="5" placeholder="Silahkan masukkan deskripsi produk" required>
<?php echo e($produk->deskripsi); ?>

                                </textarea>
                                <small id="emailHelp" class="form-text text-muted">Masukkan deskripsi produk disini!</small>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-4">
                                <label for="exampleInputEmail1"><strong>Stok Produk</strong></label>
                                <input type="number" class="form-control" name="stokProduk" id="numStok" min="1"
                                    aria-describedby="emailHelp" placeholder="Silahkan masukkan jumlah stok produk" required
                                    value="<?php echo e($produk->stok); ?>" readonly>
                                <small id="emailHelp" class="form-text text-muted">Masukkan jumlah stok produk
                                    disini!</small>
                            </div>
                            <div class="col-md-4">
                                <label for="exampleInputEmail1"><strong>Minimum Stok Produk</strong></label>
                                <input type="number" class="form-control" name="minimumStok" id="numMinimumStok"
                                    min="1" aria-describedby="emailHelp"
                                    placeholder="Silahkan masukkan harga jual produk" required
                                    value="<?php echo e($produk->minimum_stok); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukkan minimum stok produk
                                    disini!</small>
                            </div>
                            <div class="col-md-4">
                                <label for="exampleInputEmail1"><strong>Gambar Produk</strong></label>
                                <input type="file" class="form-control" name="gambarProduk" id="fileUpload"
                                    aria-describedby="emailHelp" value="<?php echo e(old('gambarProduk')); ?>" accept="image/*">
                                <small id="emailHelp" class="form-text text-muted">Upload file gambar produk
                                    disini!</small>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-3">
                                <label for="exampleInputEmail1"><strong>Status Keaktifan Produk</strong></label>
                                <br>
                                <div class="btn-group btn-group-toggle border w-100" data-toggle="buttons">
                                    <?php if($produk->status == 'aktif'): ?>
                                        <label class="btn btn-info waves-effect waves-light" id="lblStatusProdukAktif">
                                            <input type="radio" value="aktif" name="radioStatusProduk"
                                                id="optionStatusProdukAktif" class="radioStatusProduk" checked> Aktif
                                        </label>
                                        <label class="btn waves-effect waves-light" id="lblStatusProdukNonaktif">
                                            <input type="radio" value="nonaktif" name="radioStatusProduk"
                                                id="optionStatusProdukNonaktif" class="radioStatusProduk">
                                            Nonaktif
                                        </label>
                                    <?php else: ?>
                                        <label class="btn waves-effect waves-light" id="lblStatusProdukAktif">
                                            <input type="radio" value="aktif" name="radioStatusProduk"
                                                id="optionStatusProdukAktif" class="radioStatusProduk"> Aktif
                                        </label>
                                        <label class="btn btn-info waves-effect waves-light" id="lblStatusProdukNonaktif">
                                            <input type="radio" value="nonaktif" name="radioStatusProduk"
                                                id="optionStatusProdukNonaktif" class="radioStatusProduk" checked>
                                            Nonaktif
                                        </label>
                                    <?php endif; ?>


                                </div>
                                <small id="emailHelp" class="form-text text-muted">Pilih Status keaktifan produk
                                    disini!</small>
                            </div>
                            <div class="col-md-3">
                                <label for="exampleInputEmail1"><strong>Status Jual Produk</strong></label>
                                <div class="btn-group btn-group-toggle border w-100" data-toggle="buttons">
                                    <?php if($produk->status_jual == 'aktif'): ?>
                                        <label class="btn btn-info waves-effect waves-light"
                                            id="lblStatusJualProdukAktif">
                                            <input type="radio" name="radioStatusJualProduk" value="aktif"
                                                id="optionStatusJualProdukAktif" checked class="radioStatusJualProduk">
                                            Aktif
                                        </label>
                                        <label class="btn waves-effect waves-light" id="lblStatusJualProdukNonaktif">
                                            <input type="radio" name="radioStatusJualProduk" value="tidak"
                                                id="optionStatusJualProdukNonaktif" class="radioStatusJualProduk">
                                            Nonaktif
                                        </label>
                                    <?php else: ?>
                                        <label class="btn waves-effect waves-light" id="lblStatusJualProdukAktif">
                                            <input type="radio" name="radioStatusJualProduk" value="aktif"
                                                id="optionStatusJualProdukAktif" class="radioStatusJualProduk"> Aktif
                                        </label>
                                        <label class="btn btn-info waves-effect waves-light"
                                            id="lblStatusJualProdukNonaktif">
                                            <input type="radio" name="radioStatusJualProduk" value="tidak"
                                                id="optionStatusJualProdukNonaktif" class="radioStatusJualProduk" checked>
                                            Nonaktif
                                        </label>
                                    <?php endif; ?>
                                </div>
                                <small id="emailHelp" class="form-text text-muted">Pilih status jual produk
                                    disini!</small>
                            </div>
                            <div class="col-md-3">
                                <label for="exampleInputEmail1"><strong>Kategori Produk</strong></label><br>
                                <select name="kategoriProduk" id="selectKategoriProduk" class="form-control"
                                    aria-label="Default select example" required>
                                    <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($produk->kategori_id == $k->id): ?>
                                            <option value="<?php echo e($k->id); ?>" selected><?php echo e($k->nama); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <small id="emailHelp" class="form-text text-muted">Pilih kategori produk
                                    disini!</small>
                            </div>
                            <div class="col-md-3">
                                <label for="exampleInputEmail1"><strong>Merek Produk</strong></label><br>
                                <select name="merekProduk" id="selectMerekProduk" class="form-control"
                                    aria-label="Default select example" required>
                                    <?php $__currentLoopData = $mereks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($produk->merek_id == $m->id): ?>
                                            <option value="<?php echo e($m->id); ?>" selected><?php echo e($m->nama); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($m->id); ?>"><?php echo e($m->nama); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <small id="emailHelp" class="form-text text-muted">Pilih merek produk
                                    disini!</small>
                            </div>
                        </div>

                        <div class="form-group row" id="containerKeteranganKondisi">
                            <div class="col-md-12">
                                <label for="exampleInputEmail1"><strong>Kondisi Pelanggan Terhadap Produk</strong></label>
                            </div>
                            <div class="col-md-12">
                                <div class="input-group" style="width: 100%">
                                    <select style="width: 70%" name="kondisi" id="selectKondisi" class="form-control"
                                        aria-label="Default select example" required>
                                        <option value="null" selected disabled>Pilih Kondisi</option>
                                        <?php
                                            $arrayIdKondisi = [];
                                            foreach ($produk->kondisis as $k) {
                                                array_push($arrayIdKondisi, $k->id);
                                            }
                                        ?>
                                        <?php $__currentLoopData = $kondisis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kondisi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!in_array($kondisi->id, $arrayIdKondisi)): ?>
                                                <option value="<?php echo e($kondisi->id); ?>"
                                                    keterangan="<?php echo e($kondisi->keterangan); ?>">
                                                    <?php echo e($kondisi->keterangan); ?>

                                                </option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </select>
                                    <button style="margin-left: 1%; width: 20%" type="button" id="btnTambahKondisi"
                                        class="btn btn-info waves-effect waves-light">Tambah Keterangan Kondisi</button>
                                </div>
                                <small id="emailHelp" class="form-text text-muted">Pilih Kondisi Pelanggan Terhdap Produk
                                    disini!</small>
                            </div>
                            <?php $__currentLoopData = $produk->kondisis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kondisi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input id='kondisi<?php echo e($kondisi->id); ?>' type='hidden' class='classarraykondisiid'
                                    value='<?php echo e($kondisi->id); ?>' name='arraykondisiid[]'>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="form-group text-center">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th class="text-center">Keterangan Kondisi</th>
                                        <th class="text-center">Hapus</th>
                                    </tr>
                                </thead>
                                <tbody id="bodyListKeteranganKondisi">

                                    <?php $__currentLoopData = $produk->kondisis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kondisi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($kondisi->keterangan); ?>

                                            </td>
                                            <td>
                                                <button type='button'
                                                    class='deleteKondisi btn btn-danger waves-effect waves-light'
                                                    idKondisi="<?php echo e($kondisi->id); ?>"
                                                    keterangan="<?php echo e($kondisi->keterangan); ?>">Hapus</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>

                        <div class="form-group row text-right">
                            <div class="col-md-12">
                                <a id="btnBatalEditProduk" href="<?php echo e(route('produks.index')); ?>"
                                    class="btn btn-danger btn-lg waves-effect waves-light mr-3">Batal</a>
                                <button id="btnEditProduk" type="button"
                                    class="btn btn-info btn-lg waves-effect waves-light text-right">Simpan</button>
                            </div>
                        </div>

                        <div id="modalPengecekanHargaJualBeli" class="modal fade bs-example-modal-center" tabindex="-1"
                            role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title mt-0">Konfirmasi Harga Jual dan Beli Produk</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body" id="bodyModalPengecekanHarga">
                                        <h6>Harga jual produk yang Anda masukkan lebih kecil dari harga beli produk. Apakh
                                            Anda yakin untuk mengkonfirmasi penyimpanan data produk?</h6>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger waves-effect"
                                            data-dismiss="modal">Tidak</button>
                                        <button type="submit" class="btn btn-info waves-effect waves-light">Ya</button>
                                    </div>
                                </div>
                                <!-- /.modal-content -->
                            </div>
                            <!-- /.modal-dialog -->
                        </div>

                    </form>


                </div>
            </div>
        </div>
        <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        $('.radioStatusProduk').on('change', function() {
            var statusSaatIni = $(this).val();
            if (statusSaatIni == "nonaktif") {
                $("#lblStatusProdukAktif").removeClass("btn-info");
                $("#lblStatusProdukNonaktif").addClass("btn-info");
            } else {
                $("#lblStatusProdukAktif").addClass("btn-info");
                $("#lblStatusProdukNonaktif").removeClass("btn-info");
            }
        });

        $('#btnEditProduk').on('click', function() {
            var hargaJual = parseInt($("#numHargaJual").val());
            var hargaBeli = parseInt($("#numHargaBeli").val());
            var namaProduk = $("#txtNamaProduk").val();
            if (hargaJual < hargaBeli) {
                $("#bodyModalPengecekanHarga").html("<p>Harga jual produk " + namaProduk +
                    " yang Anda masukkan(Rp. " + hargaJual + ") lebih kecil dari harga beli produk(Rp. " +
                    hargaBeli + "). Apakah Anda yakin untuk mengkonfirmasi penyimpanan data produk?</p>");
                $("#modalPengecekanHargaJualBeli").modal("show");
            } else {
                $("#formUpdateProduk").submit();
            }
        });

        $('.radioStatusJualProduk').on('change', function() {
            var statusSaatIni = $(this).val();
            if (statusSaatIni == "tidak") {
                $("#lblStatusJualProdukAktif").removeClass("btn-info");
                $("#lblStatusJualProdukNonaktif").addClass("btn-info");
            } else {
                $("#lblStatusJualProdukAktif").addClass("btn-info");
                $("#lblStatusJualProdukNonaktif").removeClass("btn-info");
            }
        });

        $('body').on('click', '#btnTambahKondisi', function() {
            var idKondisi = $("#selectKondisi").val();
            var keteranganKondisi = $("#selectKondisi option:selected").text();

            if (idKondisi != null) {
                $("#containerKeteranganKondisi").append("<input id='kondisi" + idKondisi +
                    "' type='hidden' class='classarraykondisiid' value='" +
                    idKondisi +
                    "' name='arraykondisiid[]'>");
                $('#trSilahkan').remove();
                $("#bodyListKeteranganKondisi").append(
                    "<tr><td>" + keteranganKondisi + "</td>" +
                    "<td>" +
                    "<button type='button' class='deleteKondisi btn btn-danger waves-effect waves-light' idKondisi='" +
                    idKondisi +
                    "' keterangan='" + keteranganKondisi + "' >Hapus</button>" +
                    "</td>" +
                    "</tr>");
                $("#selectKondisi option:selected").remove();
                $("#selectKondisi").val('null');
            }
        });

        $('body').on('click', '.deleteKondisi', function() {
            var idKondisi = $(this).attr('idKondisi');
            var keteranganKondisi = $(this).attr('keterangan');


            $("#selectKondisi").append("<option value='" + idKondisi + "'>" + keteranganKondisi +
                "</option>");
            $(this).parent().parent().remove();
            $("#kondisi" + idKondisi).remove();

            var select = $("#selectKondisi");
            $("#selectKondisi option[value='null']").remove();
            var options = select.find("option");
            options.sort(function(a, b) {
                return a.text.localeCompare(b.text);
            });
            select.empty();
            select.append("<option value='null' selected disabled>Pilih Kondisi</option>")
            select.append(options);
            select.val("null");

            if ($('#bodyListKeteranganKondisi').find("tr").length == 0) {
                $('#bodyListKeteranganKondisi').html(
                    "<tr id='trSilahkan'><td colspan='5=2'>Silahkan Pilih Keterangan Kondisi</td></tr>");
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\salon_ta\160420050_serenity\resources\views/admin/produk/editproduk.blade.php ENDPATH**/ ?>