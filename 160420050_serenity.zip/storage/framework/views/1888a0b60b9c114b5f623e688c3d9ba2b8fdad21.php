

<?php $__env->startSection('admincontent'); ?>
    <div class="page-title-box">

    </div>
    <!-- end page-title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h3 class="mt-0 header-title">Edit Kategori Produk</h3>
                    <p class="sub-title">
                    </p>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible" role="alert">
                            <button type="button" class="close text-danger" data-dismiss="alert" aria-label="Close">
                                <span class="text-danger" aria-hidden="true">&times;</span>
                            </button>
                            <p class="mb-0"><strong>Maaf, terjadi kesalahan!</strong></p>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="mt-0 mb-1">- <?php echo e($error); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('kategoris.update', $objKategori->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group col-md-12">
                            
                        </div>

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="exampleInputEmail1"><strong>Nama Kategori</strong></label>
                                <input type="text" class="form-control" name="namaKategori" id="textNamaKategori" value="<?php echo e($objKategori->nama); ?>"
                                    aria-describedby="emailHelp" placeholder="Silahkan masukkan nama kategori" required>
                                <small id="emailHelp" class="form-text text-muted">Masukkan nama kategori disini!</small>

                            </div>
                        </div>
                        <div class="form-group text-right">
                            <div class="col-md-6">
                                <a id="btnHapusKategori" href="<?php echo e(route('kategoris.index')); ?>"
                                    class="btn btn-danger btn-lg waves-effect waves-light mr-3">Batal</a>
                                <button id="btnTambahKategori" type="submit"
                                    class="btn btn-info btn-lg waves-effect waves-light">Edit</button>
                            </div>

                        </div>

                    </form>


                </div>
            </div>
        </div>
        <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\salon_ta\serenity\resources\views/admin/produk/kategoriproduk/editkategori.blade.php ENDPATH**/ ?>