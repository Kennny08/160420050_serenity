<div class="form-group row text-center">
    
    <div class="form-group col-md-12">
        <img src="<?php echo e(asset('assets_admin/images/perawatan/')); ?>/<?php echo e($perawatan->gambar); ?>" alt="gambarPerawatan" style="max-height: 500px;" class="img-fluid">
    </div>
</div>
<div class="form-group row text-center">

    <div class="form-group col-md-6">
        <h6>Tanggal Pembuatan</h6>
        <p><?php echo e(date('d-m-Y H:i:s', strtotime($perawatan->created_at))); ?></p>
    </div>
    <div class="form-group col-md-6">
        <h6>Tanggal Terakhir Diubah</h6>
        <p><?php echo e(date('d-m-Y H:i:s', strtotime($perawatan->updated_at))); ?></p>
    </div>
</div>

<div class="form-group row text-center">
    <div class="form-group col-md-6">
        <h6>Jumlah Direservasi</h6>
        <p><?php echo e($perawatan->jmlh_reservasi); ?></p>
    </div>
    <div class="form-group col-md-6">
        <h6>Jumlah Tanpa Reservasi</h6>
        <p><?php echo e($perawatan->jmlh_tanpa_reservasi); ?></p>
    </div>
</div>

<div class="form-group text-center">
    <div class="form-group col-md-12">
        <h6>Deskripsi Perawatan</h6>
        <p><?php echo e($perawatan->deskripsi); ?></p>
    </div>
</div>
<br>

<div class="form-group text-center">
    <div class="form-group col-md-12">
        <h6>Produk yang digunakan :</h6>
        <table id="tabelDaftarPerawatanProduk" class="table dt-responsive table-bordered table-striped text-center"
            style="border-collapse: collapse; border-spacing: 0; width: 100%;">
            <thead>
                <tr>
                    <th>Nama Produk</th>
                </tr>
            </thead>
            <tbody id="bodyListPerawatanProduk">
                <?php if(count($perawatan->produks) == 0): ?>
                    <tr>
                        <td>
                            Tidak ada produk yang digunakan!
                        </td>
                    </tr>
                <?php else: ?>
                    <?php $__currentLoopData = $perawatan->produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($p->nama); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </tbody>
        </table>
    </div>
</div>
<br>
<div class="form-group text-center">
    <div class="form-group col-md-12">
        <h6>Karyawan yang Menguasai :</h6>
        <table id="tabelDaftarPerawatanKaryawan" class="table dt-responsive table-bordered table-striped text-center"
            style="border-collapse: collapse; border-spacing: 0; width: 100%;">
            <thead>
                <tr>
                    <th>Nama Karyawan</th>
                    <th>Total Perawatan</th>
                </tr>
            </thead>
            <tbody id="bodyListPerawatanProduk">
                <?php $__currentLoopData = $perawatan->karyawans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $karyawan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($karyawan->nama); ?></td>
                        <td><?php echo e($karyawan->penjualanperawatans->where('perawatan.id', $perawatan->id)->where('penjualan.status_selesai', 'selesai')->count()); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\salon_ta\160420050_serenity\resources\views/admin/perawatan/detailperawatan.blade.php ENDPATH**/ ?>