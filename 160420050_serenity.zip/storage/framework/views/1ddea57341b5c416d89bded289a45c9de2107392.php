

<?php $__env->startSection('title', 'Admin || Daftar Kategori'); ?>

<?php $__env->startSection('admincontent'); ?>
    <div class="page-title-box">
    </div>
    <!-- end page-title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h3 class="mt-0 header-title">Daftar Kategori Produk</h3>
                    <p class="sub-title">
                    </p>
                    <?php if(Auth::user()->role == 'admin' || Auth::user()->karyawan->jenis_karyawan == 'admin'): ?>
                        <a class="btn btn-info waves-effect waves-light" href=<?php echo e(route('kategoris.create')); ?>>Tambah
                            Kategori
                        </a>
                        <br>
                    <?php endif; ?>

                    <br>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <button type="button" class="close text-danger" data-dismiss="alert" aria-label="Close">
                                <span class="text-success" aria-hidden="true">&times;</span>
                            </button>
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <table id="tabelDaftarKategori" class="table table-bordered dt-responsive nowrap text-center"
                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama Kategori</th>
                                <th>Tanggal Pembuatan</th>
                                <th>Tanggal Edit Terakhir</th>
                                <th>Daftar Produk</th>
                                <?php if(Auth::user()->role == 'admin' || Auth::user()->karyawan->jenis_karyawan == 'admin'): ?>
                                    <th>Edit</th>
                                    <th>Hapus</th>
                                <?php endif; ?>

                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="tr_<?php echo e($k->id); ?>">
                                    <td><?php echo e($k->id); ?></td>
                                    <td><?php echo e($k->nama); ?></td>
                                    <td><?php echo e(date('d-m-Y H:i:s', strtotime($k->created_at))); ?></td>
                                    <td><?php echo e(date('d-m-Y H:i:s', strtotime($k->updated_at))); ?></td>
                                    <td class="text-center"><button idKategori="<?php echo e($k->id); ?>"
                                            namaKategori="<?php echo e($k->nama); ?>" data-toggle="modal"
                                            data-target="#modalDaftarProdukKategori"
                                            class=" btn btn-warning waves-effect waves-light btnDaftarProduk">Tampilkan</button>
                                    </td>
                                    <?php if(Auth::user()->role == 'admin' || Auth::user()->karyawan->jenis_karyawan == 'admin'): ?>
                                        <td class="text-center"><a href="<?php echo e(route('kategoris.edit', $k->id)); ?>"
                                                class=" btn btn-info waves-effect waves-light">Edit</a>
                                        </td>
                                        <td class="text-center"><button data-toggle="modal"
                                                data-target="#modalKonfirmasiDeleteKategori"
                                                class=" btn btn-danger waves-effect waves-light btnHapusKategori"
                                                idKategori = "<?php echo e($k->id); ?>" namaKategori="<?php echo e($k->nama); ?>"
                                                routeUrl = "<?php echo e(route('kategoris.destroy', $k->id)); ?>">Hapus</button>
                                        </td>
                                    <?php endif; ?>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
        <!-- end col -->
    </div>

    <div id="modalDaftarProdukKategori" class="modal fade bs-example-modal-center" tabindex="-1" role="dialog"
        aria-labelledby="mySmallModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-xl" style="max-width: 90%">
            <div class="modal-content ">
                <div class="modal-header">
                    <h5 class="modal-title mt-0" id="modalNamaDaftarProdukKategori">Daftar Produk</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="contentDaftarProdukKategori">
                    <div class="text-center">
                        <div class="spinner-border text-info" role="status">
                            <span class="sr-only">Loading...</span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer"> <button type="button" class="btn btn-danger waves-effect"
                        data-dismiss="modal">Tutup</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

    <div id="modalKonfirmasiDeleteKategori" class="modal fade bs-example-modal-center" tabindex="-1" role="dialog"
        aria-labelledby="mySmallModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <form id="formDeleteKategori" action="<?php echo e(route('kategoris.destroy', '1')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <div class="modal-header">
                        <h5 id="modalNamaKategori" class="modal-title mt-0">Konfirmasi Penghapusan Kategori</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div id="modalBodyHapusKategori" class="modal-body text-center">
                        <h6>Apakah Anda yakin untuk menghapus kategori?</h6>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">Batal</button>
                        <button id="btnKonfirmasiHapusKategori" type="submit"
                            class="btn btn-info waves-effect waves-light btnKonfirmasiHapusKategori">Hapus</button>
                    </div>
                </form>
            </div>

        </div>
        <!-- /.modal-dialog -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        $(document).ready(function() {
            $('#tabelDaftarKategori').DataTable({
                language: {
                    emptyTable: "Tidak terdapat Data Daftar Kategori",
                    infoEmpty: "Tidak terdapat Data Daftar Kategori",
                },
            });
        });

        $("body").on("click", ".btnDaftarProduk", function() {
            var idKategori = $(this).attr("idKategori");
            var namaKategori = $(this).attr("namaKategori");

            $('#contentDaftarProdukKategori').html(
                "<div class='text-center'>" +
                "<div class='spinner-border text-info' role='status'>" +
                "<span class='sr-only'>Loading...</span>" +
                "</div></div>");

            $("#modalNamaDaftarProdukKategori").text("Daftar Produk untuk Kategori " + namaKategori);
            $.ajax({
                type: 'POST',
                url: '<?php echo e(route('admin.kategoris.getdaftarprodukkategori')); ?>',
                data: {
                    '_token': '<?php echo csrf_token(); ?>',
                    'idKategori': idKategori,
                },
                success: function(data) {
                    $('#contentDaftarProdukKategori').html(data.msg);
                    $('#tabelDaftarProdukKategori').DataTable({
                        language: {
                            emptyTable: "Tidak terdapat Daftar Produk dengan Kategori " +
                                namaKategori,
                            infoEmpty: "Tidak terdapat Daftar Produk dengan Kategori " +
                                namaKategori,
                        },
                    });
                }
            })
        });

        $('.btnHapusKategori').on('click', function() {

            var idKategori = $(this).attr("idKategori");
            var namaKategori = $(this).attr('namaKategori');
            var routeUrl = $(this).attr('routeUrl');
            $("#modalNamaKategori").text("Konfirmasi Penghapusan Kategori " + namaKategori);
            $("#modalBodyHapusKategori").html(
                "<h6>Apakah Anda yakin untuk menghapus kategori <span class='text-danger'>" + namaKategori +
                "</span>?</h6>")
            $("#formDeleteKategori").attr("action", routeUrl);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\salon_ta\160420050_serenity\resources\views/admin/produk/kategoriproduk/index.blade.php ENDPATH**/ ?>