

<?php $__env->startSection('title', 'Karyawan || Daftar Riwayat Penjualan Keseluruhan'); ?>

<?php $__env->startSection('admincontent'); ?>
    <div class="page-title-box">
    </div>
    <!-- end page-title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h3 class="mt-0 header-title" id="grupAktif">Daftar Riwayat Penjualan Keseluruhan</h3>
                    <p class="sub-title">
                    </p>
                    <br>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success alert-dismissible" role="alert">
                            <button type="button" class="close text-success" data-dismiss="alert" aria-label="Close">
                                <span class="text-success" aria-hidden="true">&times;</span>
                            </button>
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>


                    <div class="table-responsive">
                        <div>
                            <table id="tabelDaftarRiwayatPenjualan"
                                class="tabelDaftarPenjualan table table-bordered dt-responsive nowrap text-center"
                                style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                <thead>
                                    <tr>
                                        <th>Hari</th>
                                        <th hidden>tanggalHidden</th>
                                        <th>Tanggal Penjualan</th>
                                        <th>Total Penjualan</th>
                                        <th>Total Pelayanan</th>
                                        <th>Detail</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $riwayatPenjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($r['hari_penjualan']); ?></td>
                                            <td hidden><?php echo e(date('Y-m-d', strtotime($r['tanggal_penjualan']))); ?></td>
                                            <td><?php echo e(date('d-m-Y', strtotime($r['tanggal_penjualan']))); ?></td>
                                            <td><?php echo e($r['total_penjualan']); ?></td>
                                            <td><?php echo e($r['total_pelayanan']); ?></td>
                                            <td class="text-center"><button data-toggle = "modal"
                                                    data-target = "#modalDetailPenjualanPerTanggal"
                                                    tanggalPenjualan = "<?php echo e(date('Y-m-d', strtotime($r['tanggal_penjualan']))); ?>"
                                                    hariTanggalPenjualan = "<?php echo e($r['hari_penjualan']); ?>, <?php echo e(date('d-m-Y', strtotime($r['tanggal_penjualan']))); ?>"
                                                    class=" btn btn-info waves-effect waves-light btnDetailPenjualanPerTanggal">Detail</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- end col -->
    </div>
    <div id="modalDetailPenjualanPerTanggal" class="modal fade bs-example-modal-center" tabindex="-1" role="dialog"
        aria-labelledby="mySmallModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-xl" style="max-width: 90%;">
            <div class="modal-content ">
                <div class="modal-header">
                    <h5 class="modal-title mt-0" id="modalNamaDetailPenjualanPerTanggal">Detail Riwayat Penjualan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="contentDetailPenjualanPerTanggal">
                    <div class="text-center">
                        <div class="spinner-border text-info" role="status">
                            <span class="sr-only">Loading...</span>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">Tutup</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        $(document).ready(function() {

            $("#tabelDaftarRiwayatPenjualan").DataTable({
                order: [
                    [1, "desc"],
                ],
                language: {
                    emptyTable: "Tidak terdapat penjualan perawatan untuk hari yang akan datang!",
                }
            });

        });

        $('body').on('click', '.btnDetailPenjualanPerTanggal', function() {
            var tanggalPenjualan = $(this).attr("tanggalPenjualan");
            var hariTanggalPenjualan = $(this).attr("hariTanggalPenjualan");

            $("#modalNamaDetailPenjualanPerTanggal").text(" Daftar Penjualan untuk " + hariTanggalPenjualan);

            $('#contentDetailPenjualanPerTanggal').html("<div class='text-center'>" +
                "<div class='spinner-border text-info' role='status'>" +
                "<span class='sr-only'>Loading...</span>" +
                "</div></div>");

            $.ajax({
                type: 'POST',
                url: '<?php echo e(route('penjualans.karyawan.detailpenjualankeseluruhan')); ?>',
                data: {
                    '_token': '<?php echo csrf_token(); ?>',
                    'tanggalPenjualan': tanggalPenjualan,
                },
                success: function(data) {
                    $('#contentDetailPenjualanPerTanggal').html(data.msg);
                    $('#tabelDetailDaftarPenjualan').DataTable({
                        order: [
                            [6, "asc"],
                        ],
                        language: {
                    emptyTable: "Tidak terdapat penjualan keseluruhan untuk tanggal yang dipilih!",
                }

                    });
                }
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\salon_ta\160420050_serenity\resources\views/karyawansalon/penjualan/riwayatpenjualanKeseluruhan.blade.php ENDPATH**/ ?>