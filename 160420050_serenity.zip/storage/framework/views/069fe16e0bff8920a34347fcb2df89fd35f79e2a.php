<?php $__currentLoopData = $komisiPerKaryawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komisiKaryawan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($komisiKaryawan['karyawan']->nama); ?></td>
        <td>
            <?php if($komisiKaryawan['jumlah_pelayanan'] == 0): ?>
                <?php if($komisiKaryawan['karyawan']->jenis_karyawan == 'admin'): ?>
                    Tidak ada Penjualan(Karyawan Admin)
                <?php else: ?>
                    Belum ada Penjualan yang Selesai
                <?php endif; ?>
            <?php else: ?>
                <?php echo e(date('d-m-Y', strtotime($komisiKaryawan['tanggal_awal']))); ?>

            <?php endif; ?>

        </td>
        <td>
            <?php if($komisiKaryawan['jumlah_pelayanan'] == 0): ?>
                <?php if($komisiKaryawan['karyawan']->jenis_karyawan == 'admin'): ?>
                    Tidak ada Penjualan(Karyawan Admin)
                <?php else: ?>
                    Belum ada Penjualan yang Selesai
                <?php endif; ?>
            <?php else: ?>
                <?php echo e(date('d-m-Y', strtotime($komisiKaryawan['tanggal_akhir']))); ?>

            <?php endif; ?>

        </td>
        <td><?php echo e($komisiKaryawan['jumlah_pelayanan']); ?></td>
        <td><?php echo e(number_format($komisiKaryawan['total_komisi'], 2, ',', '.')); ?></td>
        <td>
            <?php if($komisiKaryawan['jumlah_pelayanan'] != 0): ?>
                <button data-toggle="modal" data-target="#modalDetailKomisiKaryawan"
                    idKaryawan ="<?php echo e($komisiKaryawan['karyawan']->id); ?>"
                    namaKaryawan = "<?php echo e($komisiKaryawan['karyawan']->nama); ?>"
                    class=" btn btn-info waves-effect waves-light btnDetailKomisiKaryawan">Detail
                </button>
            <?php else: ?>
                <button disabled class=" btn btn-danger waves-effect waves-light btnDetailKomisiKaryawan">Detail
                </button>
            <?php endif; ?>

        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\salon_ta\160420050_serenity\resources\views/admin/karyawan/komisikaryawan/tabledaftarkomisikaryawan.blade.php ENDPATH**/ ?>