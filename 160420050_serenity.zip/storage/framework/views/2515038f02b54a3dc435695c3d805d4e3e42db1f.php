<table id="tabelDetailDiskonProduk" class="table table-striped table-bordered dt-responsive wrap text-center"
    style="border-collapse: collapse; border-spacing: 0; width: 100%;">
    <thead>
        <tr>
            <th class="align-middle">Nomor Nota</th>
            <th class="align-middle">Nama Pelanggan</th>
            <th class="align-middle">Total Harga (Rp)</th>
            <th class="align-middle">Jumlah Potongan (Rp)</th>
            <th class="align-middle">Total Pembayaran (Rp)</th>
        </tr>
    </thead>

    <tbody>
        <?php $__currentLoopData = $penjualanDiskons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr >
                <td><?php echo e($rd["penjualan"]->nomor_nota); ?></td>
                <td><?php echo e($rd["penjualan"]->pelanggan->nama); ?></td>
                <td><?php echo e(number_format( $rd["totalHarga"], 2, ",", ".")); ?></td>
                <td><?php echo e(number_format( $rd["totalPotongan"], 2, ",", ".")); ?></td>
                <td><?php echo e(number_format( $rd["totalPembayaran"], 2, ",", ".")); ?></td>
                
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
    <tfoot id="grupNonaktif">

    </tfoot>
</table>
<?php /**PATH C:\xampp\htdocs\salon_ta\160420050_serenity\resources\views/admin/diskon/detaildiskon.blade.php ENDPATH**/ ?>