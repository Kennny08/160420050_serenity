

<?php $__env->startSection('title', 'Admin || Daftar Riwayat Presensi Karyawan'); ?>

<?php $__env->startSection('admincontent'); ?>
    <div class="page-title-box">
    </div>
    <!-- end page-title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h3 class="mt-0 header-title">Daftar Riwayat Presensi Karyawan</h3>
                    <p class="sub-title">
                    </p>
                    <br>
                    <br>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <button type="button" class="close text-danger" data-dismiss="alert" aria-label="Close">
                                <span class="text-success" aria-hidden="true">&times;</span>
                            </button>
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table id="tabelDaftarRiwayatPresensiKaryawan"
                            class="table table-bordered dt-responsive nowrap text-center w-100"
                            style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                                <tr>
                                    
                                    <th>Tanggal Presensi</th>
                                    <th hidden>Tanggal</th>
                                    <th>Hadir</th>
                                    <th>Sakit</th>
                                    <th>Izin</th>
                                    <th>Absen</th>
                                    <th>Belum Konfirmasi</th>
                                    <th>Detail</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $daftarRiwayatPresensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($p['tanggalPresensiDenganHari']); ?></td>
                                        <td hidden><?php echo e($p['tanggalPresensi']); ?></td>
                                        <td><?php echo e($p['daftarPresensi']->where('keterangan', 'hadir')->where('status', 'konfirmasi')->count()); ?>

                                        </td>
                                        <td><?php echo e($p['daftarPresensi']->where('keterangan', 'sakit')->where('status', 'konfirmasi')->count()); ?>

                                        </td>
                                        <td><?php echo e($p['daftarPresensi']->where('keterangan', 'izin')->where('status', 'konfirmasi')->count()); ?>

                                        </td>
                                        <td><?php echo e($p['daftarPresensi']->where('keterangan', 'absen')->where('status', 'konfirmasi')->count()); ?>

                                        </td>
                                        <td><?php echo e($p['daftarPresensi']->where('status', 'belum')->count()); ?></td>
                                        <td>
                                            <?php if($p['objectPresensiPertamaTanpaIzin'] != null): ?>
                                                <button data-toggle="modal" data-target="#modalDetailRiwayatPresensi"
                                                    waktuBukaPresensi = "<?php echo e(date('H:i', strtotime($p['objectPresensiPertamaTanpaIzin']->created_at))); ?>"
                                                    tanggalPresensi="<?php echo e($p['tanggalPresensi']); ?>"
                                                    tanggalPresensiHari="<?php echo e($p['tanggalPresensiDenganHari']); ?>"
                                                    urlEdit = "<?php echo e(route('admin.presensikehadirans.editpresensi', $p['tanggalPresensi'])); ?>"
                                                    class=" btn btn-info waves-effect waves-light btnDetailRiwayatPresensi">Detail</button>
                                            <?php else: ?>
                                                <button data-toggle="modal" data-target="#modalDetailRiwayatPresensi"
                                                    waktuBukaPresensi = "" tanggalPresensi="<?php echo e($p['tanggalPresensi']); ?>"
                                                    tanggalPresensiHari="<?php echo e($p['tanggalPresensiDenganHari']); ?>"
                                                    urlEdit = "<?php echo e(route('admin.presensikehadirans.editpresensi', $p['tanggalPresensi'])); ?>"
                                                    class=" btn btn-info waves-effect waves-light btnDetailRiwayatPresensi">Detail</button>
                                            <?php endif; ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
        <!-- end col -->
    </div>

    <div id="modalDetailRiwayatPresensi" class="modal fade bs-example-modal-center" tabindex="-1" role="dialog"
        aria-labelledby="mySmallModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-xl" style="max-width: 90%;">
            <div class="modal-content ">
                <div class="modal-header">
                    <h5 class="modal-title mt-0" id="modalNamaDetailRiwayatPresensi">Detail Riwayat Presensi</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="contentDetailRiwayatPresensi">
                    <div class="text-center">
                        <div class="spinner-border text-info" role="status">
                            <span class="sr-only">Loading...</span>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <a id="btnEditRiwayatPresensi" style="width: 10%;" class="btn btn-info waves-effect mr-3"
                        href="#">Edit Presensi</a>
                    <button type="button" style="width: 10%;" class="btn btn-danger waves-effect"
                        data-dismiss="modal">Tutup</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        $(document).ready(function() {
            $('#tabelDaftarRiwayatPresensiKaryawan').DataTable({
                "order": [
                    [1, "desc"]
                ]
            });
        });

        $('.btnDetailRiwayatPresensi').on('click', function() {
            var tanggalPresensi = $(this).attr("tanggalPresensi");
            var tanggalPresensiHari = $(this).attr('tanggalPresensiHari');
            var urlEdit = $(this).attr('urlEdit');
            var waktuBuka = $(this).attr('waktuBukaPresensi');

            if (waktuBuka == "") {
                $("#modalNamaDetailRiwayatPresensi").text(" Detail Riwayat Presensi " + tanggalPresensiHari);
            } else {
                $("#modalNamaDetailRiwayatPresensi").text(" Detail Riwayat Presensi " + tanggalPresensiHari +
                    " - Buka pukul " + waktuBuka);
            }


            $("#btnEditRiwayatPresensi").attr("href", urlEdit);

            $.ajax({
                type: 'POST',
                url: '<?php echo e(route('admin.getdetailriwayatpresensi')); ?>',
                data: {
                    '_token': '<?php echo csrf_token(); ?>',
                    'tanggalPresensi': tanggalPresensi,
                },
                success: function(data) {
                    $('#contentDetailRiwayatPresensi').html(data.msg);
                    $('#tabelDaftarDetailRiwayatPresensi').DataTable({
                        

                    });
                }
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\salon_ta\160420050_serenity\resources\views/admin/karyawan/presensikehadiran/riwayatpresensi.blade.php ENDPATH**/ ?>