

<?php $__env->startSection('admincontent'); ?>
    <div class="page-title-box">

    </div>
    <!-- end page-title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h3 class="mt-0 header-title">Tambah Karyawan</h3>
                    <p class="sub-title">
                    </p>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible" role="alert">
                            <button type="button" class="close text-danger" data-dismiss="alert" aria-label="Close">
                                <span class="text-danger" aria-hidden="true">&times;</span>
                            </button>
                            <p class="mb-0"><strong>Maaf, terjadi kesalahan!</strong></p>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="mt-0 mb-1">- <?php echo e($error); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    <form id="formStoreKaryawan" method="POST" action="<?php echo e(route('karyawans.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group col-md-12">
                        </div>

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="exampleInputEmail1"><strong>Nama Karyawan</strong></label>
                                <input type="text" class="form-control" name="namaKaryawan" id="txtNamaKaryawan"
                                    aria-describedby="emailHelp" placeholder="Silahkan masukkan nama karyawan" required
                                    value="<?php echo e(old('namaKaryawan')); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukkan nama karyawan disini!</small>
                            </div>
                            <div class="col-md-6">
                                <label for="exampleInputEmail1"><strong>Email</strong></label>
                                <input type="email" class="form-control" name="emailKaryawan" id="txtEmailKaryawan"
                                    aria-describedby="emailHelp"
                                    placeholder="Silahkan masukkan email karyawan (ferro@gmail.com)" required
                                    value="<?php echo e(old('emailKaryawan')); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukkan email karyawan disini!</small>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="exampleInputEmail1"><strong>Gaji Pokok Karyawan</strong></label>
                                <input type="number" class="form-control" name="gajiKaryawan" id="numGajiKaryawan"
                                    min="1" aria-describedby="emailHelp"
                                    placeholder="Silahkan masukkan gaji pokok karyawan" required
                                    value="<?php echo e(old('gajiKaryawan')); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukkan gaji pokok karyawan
                                    disini!</small>
                            </div>
                            <div class="col-md-6">
                                <label for="exampleInputEmail1"><strong>Nomor Telepon</strong></label>
                                <input type="text" class="form-control" name="nomor_telepon"
                                    id="txtNomorTeleponKaryawan" aria-describedby="emailHelp"
                                    placeholder="Silahkan masukkan nomor telepon karyawan" required
                                    value="<?php echo e(old('nomor_telepon')); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukkan nomor telepon karyawan
                                    disini!</small>
                            </div>

                        </div>

                        <div class="form-group row">

                            <div class="col-md-4">
                                <label for="exampleInputEmail1"><strong>Jenis Karyawan</strong></label>
                                <br>
                                <div class="btn-group btn-group-toggle border w-100" data-toggle="buttons">
                                    <?php if(old('radioJenisKaryawan') == 'pekerja salon'): ?>
                                        <label class="btn btn-info waves-effect waves-light"
                                            id="lblJenisKaryawanPekerjaSalon">
                                            <input type="radio" value="pekerjasalon" name="radioJenisKaryawan"
                                                id="optionJenisKaryawanPekerjaSalon" class="radioJenisKaryawan" checked>
                                            Karyawan Salon
                                        </label>
                                        <label class="btn waves-effect waves-light" id="lblJenisKaryawanAdmin">
                                            <input type="radio" value="admin" name="radioJenisKaryawan"
                                                id="optionJenisKaryawanAdmin" class="radioJenisKaryawan">
                                            Admin Salon
                                        </label>
                                    <?php elseif(old('radioJenisKaryawan') == null): ?>
                                        <label class="btn btn-info waves-effect waves-light"
                                            id="lblJenisKaryawanPekerjaSalon">
                                            <input type="radio" value="pekerja salon" name="radioJenisKaryawan"
                                                id="optionJenisKaryawanPekerjaSalon" class="radioJenisKaryawan" checked>
                                            Karyawan Salon
                                        </label>
                                        <label class="btn waves-effect waves-light" id="lblJenisKaryawanAdmin">
                                            <input type="radio" value="admin" name="radioJenisKaryawan"
                                                id="optionJenisKaryawanAdmin" class="radioJenisKaryawan">
                                            Admin Salon
                                        </label>
                                    <?php else: ?>
                                        <label class="btn waves-effect waves-light" id="lblJenisKaryawanPekerjaSalon">
                                            <input type="radio" value="pekerjasalon" name="radioJenisKaryawan"
                                                id="optionJenisKaryawanPekerjaSalon" class="radioJenisKaryawan">
                                            Karyawan Salon
                                        </label>
                                        <label class="btn btn-info waves-effect waves-light" id="lblJenisKaryawanAdmin">
                                            <input type="radio" value="admin" name="radioJenisKaryawan"
                                                id="optionJenisKaryawanAdmin" class="radioJenisKaryawan" checked>
                                            Admin Salon
                                        </label>
                                    <?php endif; ?>
                                </div>
                                <small id="emailHelp" class="form-text text-muted">Pilih jenis karyawan
                                    disini!</small>
                            </div>
                            <div class="col-md-4">
                                <label for="exampleInputEmail1"><strong>Tanggal Lahir</strong></label>
                                <input type="date" class="form-control" name="tanggalLahir" id="tanggalLahir"
                                    aria-describedby="emailHelp" placeholder="Silahkan Pilih Tanggal Lahir"
                                    value="<?php echo e(old('tanggalLahir')); ?>" required>
                                <small id="emailHelp" class="form-text text-muted">Pilih tanggal lahir Karyawan
                                    disini!</small>
                            </div>
                            <div class="col-md-4">
                                <label for="exampleInputEmail1"><strong>Gender Karyawan</strong></label>
                                <br>
                                <div class="btn-group btn-group-toggle border w-100" data-toggle="buttons">
                                    <?php if(old('radioGenderKaryawan') == 'pria'): ?>
                                        <label class="btn btn-info waves-effect waves-light" id="lblGenderPria">
                                            <input type="radio" value="pria" name="radioGenderKaryawan"
                                                id="optionGenderPria" class="radioGenderKaryawan" checked>
                                            Pria
                                        </label>
                                        <label class="btn waves-effect waves-light" id="lblGenderWanita">
                                            <input type="radio" value="wanita" name="radioGenderKaryawan"
                                                id="optionGenderWanita" class="radioGenderKaryawan">
                                            Wanita
                                        </label>
                                    <?php elseif(old('radioGenderKaryawan') == null): ?>
                                        <label class="btn btn-info waves-effect waves-light" id="lblGenderPria">
                                            <input type="radio" value="pria" name="radioGenderKaryawan"
                                                id="optionGenderPria" class="radioGenderKaryawan" checked>
                                            Pria
                                        </label>
                                        <label class="btn waves-effect waves-light" id="lblGenderWanita">
                                            <input type="radio" value="wanita" name="radioGenderKaryawan"
                                                id="optionGenderWanita" class="radioGenderKaryawan">
                                            Wanita
                                        </label>
                                    <?php else: ?>
                                        <label class="btn waves-effect waves-light" id="lblGenderPria">
                                            <input type="radio" value="pria" name="radioGenderKaryawan"
                                                id="optionGenderPria" class="radioGenderKaryawan">
                                            Pria
                                        </label>
                                        <label class="btn btn-info waves-effect waves-light" id="lblGenderWanita">
                                            <input type="radio" value="wanita" name="radioGenderKaryawan"
                                                id="optionGenderWanita" class="radioGenderKaryawan" checked>
                                            Wanita
                                        </label>
                                    <?php endif; ?>
                                </div>
                                <small id="emailHelp" class="form-text text-muted">Pilih gender karyawan
                                    disini!</small>
                            </div>
                        </div>




                        <div class="form-group row" id="containerKaryawanPerawatan">
                            <div class="col-md-12">
                                <label for="exampleInputEmail1"><strong>Perawatan yang Dikuasai</strong></label>
                            </div>
                            <div class="col-md-12">
                                <div class="input-group" style="width: 100%">
                                    <select style="width: 70%" name="perawatan" id="selectPerawatan"
                                        class="form-control" aria-label="Default select example" required>
                                        <option value="null" selected disabled>Pilih Perawatan</option>
                                        <?php if(old('arrayperawatanid') == null): ?>
                                            <?php $__currentLoopData = $perawatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perawatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($perawatan->id); ?>" nama="<?php echo e($perawatan->nama); ?>">
                                                    <?php echo e($perawatan->nama); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <?php $__currentLoopData = $perawatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perawatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(!in_array($perawatan->id, old('arrayperawatanid'))): ?>
                                                    <option value="<?php echo e($perawatan->id); ?>" nama="<?php echo e($perawatan->nama); ?>">
                                                        <?php echo e($perawatan->nama); ?>

                                                    </option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>


                                    </select>
                                    <button style="margin-left: 1%; width: 20%" type="button" id="btnTambahPerawatan"
                                        class="btn btn-info waves-effect waves-light">Tambah Perawatan</button>
                                </div>
                                <small id="emailHelp" class="form-text text-muted">Pilih perawatan yang dikuasai
                                    disini!</small>
                            </div>
                            <?php if(old('arrayperawatanid') != null): ?>
                                <?php $__currentLoopData = old('arrayperawatanid'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perawatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input id='perawatan<?php echo e($perawatan); ?>' type='hidden'
                                        class='classarrayperawatanid' value='<?php echo e($perawatan); ?>'
                                        name='arrayperawatanid[]'>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>

                        <div class="form-group text-center">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th class="text-center">Perawatan</th>
                                        <th class="text-center">Hapus</th>
                                    </tr>
                                </thead>
                                <tbody id="bodyListPerawatan">
                                    <?php if(old('arrayperawatanid') == null): ?>
                                        <tr id="trSilahkan">
                                            <td colspan="2">
                                                Silahkan pilih Perawatan
                                            </td>
                                        </tr>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $perawatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perawatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(in_array($perawatan->id, old('arrayperawatanid'))): ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($perawatan->nama); ?>

                                                    </td>
                                                    <td>
                                                        <button type='button'
                                                            class='deletePerawatan btn btn-danger waves-effect waves-light'
                                                            idPerawatan="<?php echo e($perawatan->id); ?>"
                                                            namaPerawatan="<?php echo e($perawatan->nama); ?>">Hapus</button>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="form-group row text-right">
                            <div class="col-md-12">
                                <a id="btnBatalTambahProduk" href="<?php echo e(route('karyawans.index')); ?>"
                                    class="btn btn-danger btn-lg waves-effect waves-light mr-3">Batal</a>
                                <button id="btnTambahProduk" type="submit"
                                    class="btn btn-info btn-lg waves-effect waves-light text-right">Tambah</button>
                            </div>
                        </div>

                        

                    </form>


                </div>
            </div>
        </div>
        <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        $('.radioJenisKaryawan').on('change', function() {
            var jenisKaryawanSaatIni = $(this).val();
            if (jenisKaryawanSaatIni == "admin") {
                $("#lblJenisKaryawanPekerjaSalon").removeClass("btn-info");
                $("#lblJenisKaryawanAdmin").addClass("btn-info");
            } else {
                $("#lblJenisKaryawanPekerjaSalon").addClass("btn-info");
                $("#lblJenisKaryawanAdmin").removeClass("btn-info");
            }
        });

        $('.radioGenderKaryawan').on('change', function() {
            var statusSaatIni = $(this).val();
            if (statusSaatIni == "wanita") {
                $("#lblGenderPria").removeClass("btn-info");
                $("#lblGenderWanita").addClass("btn-info");
            } else {
                $("#lblGenderPria").addClass("btn-info");
                $("#lblGenderWanita").removeClass("btn-info");
            }
        });

        $('#btnTambahProduk').on('click', function() {
            var hargaJual = parseInt($("#numHargaJual").val());
            var hargaBeli = parseInt($("#numHargaBeli").val());
            var namaProduk = $("#txtNamaProduk").val();
            if (hargaJual < hargaBeli) {
                $("#bodyModalPengecekanHarga").html("<p>Harga jual produk " + namaProduk +
                    " yang Anda masukkan(Rp. " + hargaJual + ") lebih kecil dari harga beli produk(Rp. " +
                    hargaBeli + "). Apakah Anda yakin untuk mengkonfirmasi penyimpanan data produk?</p>");
                $("#modalPengecekanHargaJualBeli").modal("show");
            } else {
                $("#formStoreProduk").submit();
            }
        });



        $('body').on('click', '#btnTambahPerawatan', function() {
            var idPerawatan = $("#selectPerawatan").val();
            var namaPerawatan = $("#selectPerawatan option:selected").text();

            if (idPerawatan != null) {
                $("#containerKaryawanPerawatan").append("<input id='perawatan" + idPerawatan +
                    "' type='hidden' class='classarrayperawatanid' value='" +
                    idPerawatan +
                    "' name='arrayperawatanid[]'>");
                $('#trSilahkan').remove();
                $("#bodyListPerawatan").append(
                    "<tr><td>" + namaPerawatan + "</td>" +
                    "<td>" +
                    "<button type='button' class='deletePerawatan btn btn-danger waves-effect waves-light' idPerawatan='" +
                    idPerawatan +
                    "' namaPerawatan='" + namaPerawatan + "' >Hapus</button>" +
                    "</td>" +
                    "</tr>");
                $("#selectPerawatan option:selected").remove();
                $("#selectPerawatan").val('null');
            }
        });

        $('body').on('click', '.deletePerawatan', function() {
            var idPerawatan = $(this).attr('idPerawatan');
            var namaPerawatan = $(this).attr('namaPerawatan');


            $("#selectPerawatan").append("<option value='" + idPerawatan + "'>" + namaPerawatan +
                "</option>");
            $(this).parent().parent().remove();
            $("#perawatan" + idPerawatan).remove();

            var select = $("#selectPerawatan");
            $("#selectPerawatan option[value='null']").remove();
            var options = select.find("option");
            options.sort(function(a, b) {
                return a.text.localeCompare(b.text);
            });
            select.empty();
            select.append("<option value='null' selected disabled>Pilih Perawatan</option>")
            select.append(options);
            select.val("null");

            if ($('#bodyListPerawatan').find("tr").length == 0) {
                $('#bodyListPerawatan').html(
                    "<tr id='trSilahkan'><td colspan='5=2'>Silahkan Pilih Keterangan Perawatan</td></tr>");
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\salon_ta\serenity\resources\views/admin/karyawan/tambahkaryawan.blade.php ENDPATH**/ ?>