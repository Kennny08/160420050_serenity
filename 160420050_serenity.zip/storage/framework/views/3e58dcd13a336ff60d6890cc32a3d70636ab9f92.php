

<?php $__env->startSection('title', 'Admin || Edit Paket'); ?>

<?php $__env->startSection('admincontent'); ?>
    <div class="page-title-box">

    </div>
    <!-- end page-title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h3 class="mt-0 header-title">Edit Paket</h3>
                    <p class="sub-title">
                    </p>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible" role="alert">
                            <button type="button" class="close text-danger" data-dismiss="alert" aria-label="Close">
                                <span class="text-danger" aria-hidden="true">&times;</span>
                            </button>
                            <p class="mb-0"><strong>Maaf, terjadi kesalahan!</strong></p>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="mt-0 mb-1">- <?php echo e($error); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    <form id="formUpdatePaket" method="POST" action="<?php echo e(route('pakets.update', $paket->id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group col-md-12">
                        </div>

                        <div class="form-group row">
                            <div class="col-md-4">
                                <label for="exampleInputEmail1"><strong>Nama Paket</strong></label>
                                <input type="text" class="form-control" name="namaPaket" id="txtNamaPaket"
                                    aria-describedby="emailHelp" placeholder="Silahkan masukkan nama paket" required
                                    value="<?php echo e($paket->nama); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukkan nama paket disini!</small>
                            </div>
                            <div class="col-md-4">
                                <label for="exampleInputEmail1"><strong>Kode Paket</strong></label>
                                <input type="text" class="form-control" name="kode_paket" id="txtKodePaket"
                                    aria-describedby="emailHelp" placeholder="Silahkan masukkan kode paket" required
                                    value="<?php echo e($paket->kode_paket); ?>" readonly>
                                <small id="emailHelp" class="form-text text-muted">Masukkan jumlah kode disini!</small>
                            </div>
                            <div class="col-md-4">
                                <label for="exampleInputEmail1"><strong>Gambar Paket</strong></label>
                                <input type="file" class="form-control" name="gambarPaket" id="fileUpload"
                                    aria-describedby="emailHelp" value="<?php echo e(old('gambarPaket')); ?>" accept="image/*">
                                <small id="emailHelp" class="form-text text-muted">Upload file gambar paket
                                    disini!</small>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-4">
                                <?php if($paket->diskon_id != null): ?>
                                    <label for="exampleInputEmail1"><strong>Diskon Paket</strong></label>
                                    <input type="text" class="form-control" name="idDiskon" id="txtDiskonPaket"
                                        aria-describedby="emailHelp" placeholder="Silahkan masukkan kode paket" required
                                        value="<?php echo e($paket->diskon->nama); ?>" readonly>
                                    <small id="emailHelp" class="form-text text-muted">Diskon yang Berlaku untuk Paket
                                        ini!</small>
                                <?php else: ?>
                                    <label for="exampleInputEmail1"><strong>Diskon Paket</strong></label>
                                    <input type="text" class="form-control" name="idDiskon" id="txtDiskonPaket"
                                        aria-describedby="emailHelp" placeholder="Silahkan masukkan kode paket" required
                                        value="Tidak Ada diskon yang ditetapkan untuk paket ini!" readonly>
                                    <small id="emailHelp" class="form-text text-muted">Diskon yang Berlaku untuk Paket
                                        ini!</small>
                                <?php endif; ?>

                            </div>
                            <div class="col-md-4">
                                <label for="exampleInputEmail1"><strong>Harga Paket(Rp)</strong></label>
                                <input type="number" class="form-control" name="hargaPaket" id="numHargaPaket"
                                    min="1" aria-describedby="emailHelp"
                                    placeholder="Silahkan masukkan harga layanan paket" required
                                    value="<?php echo e($paket->harga); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukkan harga paket
                                    disini!</small>
                            </div>
                            <div class="col-md-4">
                                <label for="exampleInputEmail1"><strong>Status Keaktifan Paket</strong></label>
                                <br>
                                <div class="btn-group btn-group-toggle border w-100" data-toggle="buttons">
                                    <?php if($paket->status == 'aktif'): ?>
                                        <label class="btn btn-info waves-effect waves-light" id="lblStatusPaketAktif">
                                            <input type="radio" value="aktif" name="radioStatusPaket"
                                                id="optionStatusPaketAktif" class="radioStatusPaket" checked>
                                            Aktif
                                        </label>
                                        <label class="btn waves-effect waves-light" id="lblStatusPaketNonaktif">
                                            <input type="radio" value="nonaktif" name="radioStatusPaket"
                                                id="optionStatusPaketNonaktif" class="radioStatusPaket">
                                            Nonaktif
                                        </label>
                                    <?php else: ?>
                                        <label class="btn waves-effect waves-light" id="lblStatusPaketAktif">
                                            <input type="radio" value="aktif" name="radioStatusPaket"
                                                id="optionStatusPaketAktif" class="radioStatusPaket"> Aktif
                                        </label>
                                        <label class="btn btn-info waves-effect waves-light" id="lblStatusPaketNonaktif">
                                            <input type="radio" value="nonaktif" name="radioStatusPaket"
                                                id="optionStatusPaketNonaktif" class="radioStatusPaket" checked>
                                            Nonaktif
                                        </label>
                                    <?php endif; ?>
                                </div>
                                <small id="emailHelp" class="form-text text-muted">Pilih Status keaktifan paket
                                    disini!</small>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-12">
                                <label for="exampleInputEmail1"><strong>Deskripsi Paket</strong></label>
                                <textarea aria-describedby="emailHelp" class="form-control" name="deskripsiPaket" id="" cols="30"
                                    rows="5" placeholder="Silahkan masukkan deskripsi paket" required>
<?php echo e($paket->deskripsi); ?>

                                </textarea>
                                <small id="emailHelp" class="form-text text-muted">Masukkan deskripsi paket
                                    disini!</small>
                            </div>
                        </div>

                        

                        <div class="form-group row text-center">
                            <div class="col-md-12 text-left">
                                <h5>Daftar Perawatan</h5>
                            </div>
                            <div class="form-group col-md-12 table-responsive">
                                <div>
                                    <table class="table table-bordered table-striped dt-responsive wrap">
                                        <thead>
                                            <tr>
                                                <th class="text-center">Nama Perawatan</th>
                                                <th class="text-center">Durasi (Menit)</th>
                                                <th class="text-center">Harga (Rp)</th>
                                                <th class="text-center">Deskripsi</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody id="bodyListPerawatan">

                                            <?php $__currentLoopData = $arrPerawatanId; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idPerawatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $aro = $paket->perawatans->firstWhere('id', $idPerawatan);
                                                ?>
                                                <tr>
                                                    <td> <?php echo e($aro->nama); ?> </td>
                                                    <td><?php echo e($aro->durasi); ?> </td>
                                                    <td><?php echo e(number_format($aro->harga, 2, ',', '.')); ?> </td>
                                                    <td><?php echo e($aro->deskripsi); ?></td>
                                                    
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            
                                        </tbody>
                                        <tfoot>
                                            <?php
                                                $totalPerawatanSementara = 0;
                                            ?>
                                            <?php $__currentLoopData = $paket->perawatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perawatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $totalPerawatanSementara += $perawatan->harga;
                                                ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td id="tabelTotalHargaPerawatan" colspan="5" class="font-weight-bold"
                                                    total="<?php echo e($totalPerawatanSementara); ?>">
                                                    Total Harga
                                                    :
                                                    Rp. <?php echo e(number_format($totalPerawatanSementara, 2, ',', '.')); ?>

                                                </td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>

                        

                        <div class="form-group row text-center">
                            <div class="col-md-12 text-left">
                                <h5>Daftar Produk</h5>
                            </div>
                            <div class="form-group col-md-12 table-responsive">
                                <div>
                                    <table class="table table-bordered table-striped dt-responsive wrap">
                                        <thead>
                                            <tr>
                                                <th class="text-center">Nama Produk</th>
                                                <th class="text-center">Harga Produk(Rp)</th>
                                                <th class="text-center">Kuantitas</th>
                                                <th class="text-center">Subtotal(Rp)</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody id="bodyListProduk">
                                            <?php if(count($paket->produks) == 0): ?>
                                                <tr id="trSilahkan">
                                                    <td colspan="4">
                                                        Silahkan pilih Produk!
                                                    </td>
                                                </tr>
                                            <?php else: ?>
                                                <?php $__currentLoopData = $paket->produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td>
                                                            <?php echo e($p->nama); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e(number_format($p->harga_jual, 2, ',', '.')); ?>

                                                        </td>
                                                        <td><?php echo e($p->pivot->jumlah); ?></td>
                                                        <td>
                                                            <?php
                                                                $subtotal = $p->harga_jual * $p->pivot->jumlah;
                                                            ?>
                                                            <?php echo e(number_format($subtotal, 2, ',', '.')); ?>

                                                        </td>
                                                        
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </tbody>
                                        <tfoot>
                                            <?php
                                                $totalProdukSementara = 0;
                                            ?>
                                            <?php if(count($paket->produks) != 0): ?>
                                                <?php $__currentLoopData = $paket->produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $totalProdukSementara += $produk->harga_jual * $produk->pivot->jumlah;
                                                    ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td id="tabelTotalHargaProduk" colspan="5"
                                                        class="font-weight-bold" total="<?php echo e($totalProdukSementara); ?>">
                                                        Total Harga
                                                        :
                                                        Rp. <?php echo e(number_format($totalProdukSementara, 2, ',', '.')); ?>

                                                    </td>
                                                </tr>
                                            <?php else: ?>
                                                <tr>
                                                    <td id="tabelTotalHargaProduk" colspan="5"
                                                        class="font-weight-bold" total="0">Total Harga
                                                        :
                                                        Rp. 0,00
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        </tfoot>
                                    </table>
                                </div>

                            </div>
                        </div>


                        <div class="form-group row text-right">
                            <div class="col-md-12">
                                <a id="btnBatalTambahPaket" href="<?php echo e(route('pakets.index')); ?>"
                                    class="btn btn-danger btn-lg waves-effect waves-light mr-3">Batal</a>
                                <button id="btnTambahPaket" type="submit"
                                    class="btn btn-info btn-lg waves-effect waves-light text-right">Simpan</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        $('.radioStatusPaket').on('change', function() {
            var statusSaatIni = $(this).val();
            if (statusSaatIni == "nonaktif") {
                $("#lblStatusPaketAktif").removeClass("btn-info");
                $("#lblStatusPaketNonaktif").addClass("btn-info");
            } else {
                $("#lblStatusPaketAktif").addClass("btn-info");
                $("#lblStatusPaketNonaktif").removeClass("btn-info");
            }
        });


        $('body').on('click', '#btnTambahLayanan', function() {
            var perawatanid = $("#perawatanSelect").val();
            var namaperawatan = $("#perawatanSelect option:selected").text();
            var durasiperawatan = $("#perawatanSelect option:selected").attr('durasi');
            var hargaperawatan = parseInt($("#perawatanSelect option:selected").attr('harga'));
            var deskripsiperawatan = $("#perawatanSelect option:selected").attr('deskripsi');
            var tanggalReservasi = $("#tanggalReservasi").val();
            var totalHargaPerawatanSaatIni = parseInt($("#tabelTotalHargaPerawatan").attr("total"));


            if (perawatanid != null) {
                $("#containerLayananPerawatan").append("<input id='perawatan" + perawatanid +
                    "' type='hidden' class='classarrayperawatanid' value='" +
                    perawatanid +
                    "' name='arrayperawatanid[]'>");
                $('#trSilahkanPerawatan').remove();
                $("#bodyListPerawatan").append(
                    "<tr><td>" + namaperawatan + "</td>" +
                    "<td>" + durasiperawatan + "</td>" +
                    "<td>" + parseInt(hargaperawatan).toLocaleString('id-ID', {
                        style: 'currency',
                        currency: 'IDR'
                    }).toString().replace("Rp", "") + "</td>" +
                    "<td>" + deskripsiperawatan + "</td>" +
                    "<td>" +
                    "<button type='button' class='deletePerawatan btn btn-danger waves-effect waves-light' idPerawatan='" +
                    perawatanid +
                    "' namaPerawatan='" + namaperawatan + "' durasiPerawatan='" + durasiperawatan +
                    "' hargaPerawatan='" +
                    hargaperawatan + "' deskripsiPerawatan='" + deskripsiperawatan + "'>Hapus</button>" +
                    "</td>" +
                    "</tr>");
                $("#perawatanSelect option:selected").remove();
                $("#perawatanSelect").val('null');
                // $('#cardDetailPerawatan').html(
                //     "<div class='alert alert-info' role='alert'><h6><strong>Silahkan Pilih Perawatan terlebih dahulu!</strong></h6></div>"
                // );
                var totalHargaBaru = totalHargaPerawatanSaatIni + hargaperawatan;
                $("#tabelTotalHargaPerawatan").attr("total", totalHargaBaru);
                $("#tabelTotalHargaPerawatan").text("Total Harga : " + totalHargaBaru.toLocaleString('id-ID', {
                    style: 'currency',
                    currency: 'IDR'
                }).toString());

                $("#numHargaPaket").val(parseInt($("#tabelTotalHargaPerawatan").attr("total")) + parseInt($(
                    "#tabelTotalHargaProduk").attr("total")));
            }
        });

        // $('body').on('click', '.deletePerawatan', function() {
        //     var perawatanid = $(this).attr('idPerawatan');
        //     var namaPerawatan = $(this).attr('namaPerawatan');
        //     var durasiperawatan = $(this).attr('durasiPerawatan');
        //     var hargaperawatan = parseInt($(this).attr('hargaPerawatan'));
        //     var deskripsiperawatan = $(this).attr('deskripsiPerawatan');
        //     var tanggalReservasi = $("#tanggalReservasi").val();
        //     var totalHargaPerawatanSaatIni = parseInt($("#tabelTotalHargaPerawatan").attr("total"));

        //     var totalHargaBaru = totalHargaPerawatanSaatIni - hargaperawatan;
        //     $("#tabelTotalHargaPerawatan").attr("total", totalHargaBaru);
        //     $("#tabelTotalHargaPerawatan").text("Total Harga : " + totalHargaBaru.toLocaleString('id-ID', {
        //         style: 'currency',
        //         currency: 'IDR'
        //     }).toString());

        //     $("#perawatanSelect").append("<option value='" + perawatanid + "' durasi='" + durasiperawatan +
        //         "' harga='" + hargaperawatan + "' deskripsi='" + deskripsiperawatan + "'>" + namaPerawatan +
        //         "</option>");
        //     $(this).parent().parent().remove();
        //     $("#perawatan" + perawatanid).remove();

        //     var select = $("#perawatanSelect");
        //     $("#perawatanSelect option[value='null']").remove();
        //     var options = select.find("option");
        //     options.sort(function(a, b) {
        //         return a.text.localeCompare(b.text);
        //     });
        //     select.empty();
        //     select.append("<option value='null' selected disabled>Pilih Perawatan</option>")
        //     select.append(options);
        //     select.val("null");

        //     if ($('#bodyListPerawatan').find("tr").length == 0) {
        //         $('#bodyListPerawatan').html(
        //             "<tr id='trSilahkanPerawatan'><td colspan='5'>Silahkan Pilih Perawatan</td></tr>");
        //     }

        //     $("#numHargaPaket").val(parseInt($("#tabelTotalHargaPerawatan").attr("total")) + parseInt($(
        //         "#tabelTotalHargaProduk").attr("total")));
        // });

        // $('body').on('click', '#btnTambahProduk', function() {
        //     var idProduk = $("#selectProduk").val();
        //     var namaProduk = unescape($("#selectProduk option:selected").attr("nama"));
        //     var hargaproduk = parseInt($("#selectProduk option:selected").attr('hargajual'));
        //     var kuantitasProduk = parseInt($("#numKuantitasProduk").val());
        //     var totalHargaProdukSaatIni = parseInt($("#tabelTotalHargaProduk").attr("total"));

        //     if (kuantitasProduk <= 0 || (isNaN(kuantitasProduk))) {
        //         kuantitasProduk = 1;
        //     }

        //     if (idProduk != null) {
        //         $("#containerProduk").append("<input id='produk" + idProduk +
        //             "' type='hidden' class='classarrayprodukid' value='" +
        //             idProduk +
        //             "' name='arrayprodukid[]'>");
        //         $("#containerProduk").append("<input id='kuantitasproduk" + idProduk +
        //             "' type='hidden' class='classarrayprodukkuantitas' value='" +
        //             kuantitasProduk +
        //             "' name='arrayprodukkuantitas[]'>");
        //         $('#trSilahkan').remove();
        //         $("#bodyListProduk").append(
        //             "<tr><td>" + namaProduk + "</td>" +
        //             "<td>" + hargaproduk.toLocaleString('id-ID', {
        //                 style: 'currency',
        //                 currency: 'IDR'
        //             }).toString().replace("Rp", "") + "</td>" +
        //             "<td>" + kuantitasProduk + "</td>" +
        //             "<td>" + (hargaproduk * kuantitasProduk).toLocaleString('id-ID', {
        //                 style: 'currency',
        //                 currency: 'IDR'
        //             }).toString().replace("Rp", "") + "</td>" +
        //             "<td>" +
        //             "<button type='button' class='deleteProduk btn btn-danger waves-effect waves-light' idProduk='" +
        //             idProduk + "' nama='" + escape(namaProduk) + "' hargajual='" + hargaproduk +
        //             "' subtotal= '" + hargaproduk * kuantitasProduk + "'>Hapus</button>" +
        //             "</td>" +
        //             "</tr>");
        //         $("#selectProduk option:selected").remove();
        //         $("#selectProduk").val('null');
        //         $("#numKuantitasProduk").val("1");
        //         var totalHargaBaru = totalHargaProdukSaatIni + (hargaproduk * kuantitasProduk);
        //         $("#tabelTotalHargaProduk").attr("total", totalHargaBaru);
        //         $("#tabelTotalHargaProduk").text("Total Harga : " + totalHargaBaru.toLocaleString('id-ID', {
        //             style: 'currency',
        //             currency: 'IDR'
        //         }).toString());

        //         $("#numHargaPaket").val(parseInt($("#tabelTotalHargaPerawatan").attr("total")) + parseInt($(
        //             "#tabelTotalHargaProduk").attr("total")));
        //     }
        // });

        // $('body').on('click', '.deleteProduk', function() {
        //     var idProduk = $(this).attr('idProduk');
        //     var namaProduk = unescape($(this).attr('nama'));
        //     var hargaProduk = $(this).attr('hargajual');
        //     var subTotalProduk = parseInt($(this).attr('subtotal'));
        //     var totalHargaProdukSaatIni = parseInt($("#tabelTotalHargaProduk").attr("total"));

        //     var totalHargaBaru = totalHargaProdukSaatIni - subTotalProduk;
        //     $("#tabelTotalHargaProduk").attr("total", totalHargaBaru);
        //     $("#tabelTotalHargaProduk").text("Total Harga : " + totalHargaBaru.toLocaleString('id-ID', {
        //         style: 'currency',
        //         currency: 'IDR'
        //     }).toString());


        //     $("#selectProduk").append("<option value='" + idProduk + "' nama='" + escape(namaProduk) +
        //         "' hargajual='" +
        //         hargaProduk + "'>" + namaProduk + "</option>");
        //     $(this).parent().parent().remove();
        //     $("#produk" + idProduk).remove();
        //     $("#kuantitasproduk" + idProduk).remove();

        //     var select = $("#selectProduk");
        //     $("#selectProduk option[value='null']").remove();
        //     var options = select.find("option");
        //     options.sort(function(a, b) {
        //         return a.text.localeCompare(b.text);
        //     });
        //     select.empty();
        //     select.append("<option value='null' selected disabled>Pilih Produk</option>")
        //     select.append(options);
        //     select.val("null");

        //     if ($('#bodyListProduk').find("tr").length == 0) {
        //         $('#bodyListProduk').html(
        //             "<tr id='trSilahkan'><td colspan='5'>Silahkan Pilih Produk</td></tr>");
        //     }
        //     $("#numHargaPaket").val(parseInt($("#tabelTotalHargaPerawatan").attr("total")) + parseInt($(
        //         "#tabelTotalHargaProduk").attr("total")));
        // });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\salon_ta\160420050_serenity\resources\views/admin/paket/editpaket.blade.php ENDPATH**/ ?>