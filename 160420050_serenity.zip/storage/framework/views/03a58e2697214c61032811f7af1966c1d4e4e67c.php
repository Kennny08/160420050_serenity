<div class="form-group row">
    <div class="form-group col-md-12">
        <table id="tabelDetailDaftarReservasi" class="table table-bordered dt-responsive nowrap text-center"
            style="border-collapse: collapse; border-spacing: 0; width: 100%;">
            <thead>
                <tr>
                    <th>ID</th>
                    <th hidden>tanggalHidden</th>
                    <th>Tanggal Pembuatan Reservasi</th>
                    <th>Tanggal Reservasi</th>

                    <th>Jam Mulai</th>
                    <th>Status</th>
                    <th>Pelanggan</th>
                    <th>No. Nota Penjualan</th>
                    <th>Total Pembayaran(Rp)</th>
                    <th>Detail</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $riwayatReservasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="tr_<?php echo e($r->id); ?>">
                        <td><?php echo e($r->id); ?></td>
                        <td hidden><?php echo e(date('Y-m-d', strtotime($r->tanggal_reservasi))); ?></td>
                        <td><?php echo e(date('d-m-Y H:i:s', strtotime($r->tanggal_pembuatan_reservasi))); ?></td>
                        <td><?php echo e(date('d-m-Y', strtotime($r->tanggal_reservasi))); ?></td>
                        <td>
                            <?php echo e($r->penjualan->penjualanperawatans()->orderBy('id')->first()->slotjams()->orderBy('slot_jam_id')->first()->jam); ?>

                        </td>
                        <td>
                            <?php if($r->status == 'dibatalkan salon' || $r->status == 'dibatalkan pelanggan' || $r->status == 'tidak hadir'): ?>
                                <span class="text-danger font-16"><?php echo e($r->status); ?></span>
                            <?php elseif($r->status == 'selesai'): ?>
                                <span class="text-success font-16"><?php echo e($r->status); ?></span>
                            <?php else: ?>
                                <span class="text-warning font-16"><?php echo e($r->status); ?></span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($r->penjualan->pelanggan->nama); ?></td>
                        <td><?php echo e($r->penjualan->nomor_nota); ?></td>
                        <td><?php echo e(number_format($r->penjualan->total_pembayaran, 2, ",", ".")); ?></td>
                        <td class="text-center"><a href="<?php echo e(route('reservasi.admin.detailreservasi', $r->id)); ?>"
                                class=" btn btn-info waves-effect waves-light">Detail</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\salon_ta\160420050_serenity\resources\views/admin/reservasi/detailreservasiperawatan.blade.php ENDPATH**/ ?>