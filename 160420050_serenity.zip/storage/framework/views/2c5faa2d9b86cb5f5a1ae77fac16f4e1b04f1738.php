<div>
    <table id="tabelDaftarDetailRiwayatPresensi" class="table table-bordered dt-responsive nowrap text-center w-100"
        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
        <thead>
            <tr>
                <th>Nama Karyawan</th>
                <th>Waktu Presensi Karyawan</th>
                <th>Keterangan</th>
                <th>Status</th>
                <th>Dikonfirmasi Terakhir Pukul</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $presensis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr id="tr_<?php echo e($p->id); ?>">
                    <td><?php echo e($p->karyawan->nama); ?></td>
                    <td>
                        <?php if(date('H:i:s', strtotime($p->created_at)) == date('H:i:s', strtotime($p->tanggal_presensi))): ?>
                            <?php if($p->keterangan == 'izin' || $p->keterangan == 'sakit'): ?>
                                <?php echo e(date('d-m-Y H:i', strtotime($p->created_at))); ?>

                            <?php else: ?>
                                <span class="text-danger">Tidak Presensi</span>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php if($p->keterangan == 'izin' || $p->keterangan == 'sakit'): ?>
                                <?php echo e(date('d-m-Y H:i', strtotime($p->created_at))); ?>

                            <?php else: ?>
                                <?php echo e(date('H:i', strtotime($p->tanggal_presensi))); ?>

                            <?php endif; ?>
                        <?php endif; ?>
                    </td>

                    <?php if($p->keterangan == 'hadir'): ?>
                        <td class="text-success">HADIR</td>
                    <?php elseif($p->keterangan == 'absen'): ?>
                        <td class="text-danger">ABSEN</td>
                    <?php elseif($p->keterangan == 'izin'): ?>
                        <td class="text-warning">IZIN</td>
                    <?php elseif($p->keterangan == 'sakit'): ?>
                        <td class="text-info">SAKIT</td>
                    <?php endif; ?>

                    <?php if($p->keterangan == 'izin'): ?>
                        <?php if($p->status == 'belum'): ?>
                            <td><span class="text-warning font-weight-bold">Belum
                                    Dikonfirmasi</span></td>
                        <?php elseif($p->status == 'konfirmasi'): ?>
                            <td><span class="text-success font-weight-bold">Telah
                                    Dikonfirmasi</span></td>
                        <?php elseif($p->status == 'tolak'): ?>
                            <td><span class="text-danger font-weight-bold">Izin Ditolak</span></td>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if($p->status == 'belum'): ?>
                            <td><span class="text-warning font-weight-bold">Belum
                                    Dikonfirmasi</span></td>
                        <?php elseif($p->status == 'konfirmasi'): ?>
                            <td><span class="text-success font-weight-bold">Telah
                                    Dikonfirmasi</span></td>
                        <?php endif; ?>
                    <?php endif; ?>

                    <td>
                        <?php if($p->status == 'belum'): ?>
                            Menunggu Konfirmasi
                        <?php else: ?>
                            <?php echo e(date('d-m-Y H:i', strtotime($p->updated_at))); ?>

                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\salon_ta\160420050_serenity\resources\views/admin/karyawan/presensikehadiran/detailriwayatpresensi.blade.php ENDPATH**/ ?>