<div>
    <table id="tabelDaftarDetailRiwayatIzin" class="table table-bordered dt-responsive nowrap text-center w-100"
        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
        <thead>
            <tr>
                <th>Nama Karyawan</th>
                <th>Keterangan</th>
                <th>Waktu Pengajuan izin</th>
                <th>Tanggal Izin</th>
                <th>Deskripsi Izin</th>
                <th>File Tambahan</th>
                <th>Status</th>
                <th>Dikonfirmasi Terakhir Pukul</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $daftarPresensiIzin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr id="tr_<?php echo e($p->id); ?>">
                    <td><?php echo e($p->karyawan->nama); ?></td>
                    <?php if($p->keterangan == 'izin'): ?>
                        <td class="text-warning">IZIN</td>
                    <?php elseif($p->keterangan == 'sakit'): ?>
                        <td class="text-info">SAKIT</td>
                    <?php endif; ?>
                    <td>
                        <?php echo e(date('d-m-Y H:i', strtotime($p->created_at))); ?>

                    </td>
                    <td>
                        <?php echo e(date('d-m-Y', strtotime($p->tanggal_presensi))); ?>

                    </td>

                    <td><?php echo e($p->deskripsi); ?></td>

                    <td>
                        <?php if($p->file_tambahan != null): ?>
                            <button data-toggle="modal" data-target="#modalFileTambahan"
                                class="btn btn-info waves-effect waves-light btnLihatFileTambahan"
                                namaImage="<?php echo e(asset('assets_admin/images/izin_sakit_karyawan/')); ?>/<?php echo e($p->file_tambahan); ?>">Lihat
                            </button>
                        <?php else: ?>
                            Tidak ada File Tambahan
                        <?php endif; ?>
                    </td>


                    <td id="statusKonfirmasi_<?php echo e($p->id); ?>">
                        <?php if($p->status == 'belum'): ?>
                            <span class="text-warning font-weight-bold">Belum
                                Dikonfirmasi</span>
                        <?php elseif($p->status == 'konfirmasi'): ?>
                            <span class="text-success font-weight-bold">Telah
                                Dikonfirmasi</span>
                        <?php elseif($p->status == 'tolak'): ?>
                            <span class="text-danger font-weight-bold">Izin Ditolak</span>
                        <?php endif; ?>
                    </td>

                    <td class="align-middle" id="waktuKonfirmasi_<?php echo e($p->id); ?>">
                        <?php if($p->status == 'belum'): ?>
                            <button id="btnKonfirmasiIzin" type="button" data-toggle= "modal"
                                data-target="#modalKonfirmasiIzin"
                                class="btn btn-info waves-effect mr-2 btnKonfirmasiIzin"
                                idPresensi="<?php echo e($p->id); ?>" keterangan="konfirmasi"
                                namaKaryawan = "<?php echo e($p->karyawan->nama); ?>"
                                tanggalIzin = "<?php echo e(date('d-m-Y', strtotime($p->tanggal_presensi))); ?>">Konfirmasi</button>
                            <button id="btnTolakIzin" type="button" data-toggle= "modal"
                                data-target="#modalKonfirmasiIzin" class="btn btn-danger waves-effect btnKonfirmasiIzin"
                                idPresensi="<?php echo e($p->id); ?>" keterangan="tolak"
                                namaKaryawan = "<?php echo e($p->karyawan->nama); ?>"
                                tanggalIzin = "<?php echo e(date('d-m-Y', strtotime($p->tanggal_presensi))); ?>">Tolak</button>
                        <?php else: ?>
                            <?php echo e(date('d-m-Y H:i', strtotime($p->updated_at))); ?>

                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\salon_ta\160420050_serenity\resources\views/admin/karyawan/presensikehadiran/detailizinkehadiran.blade.php ENDPATH**/ ?>