

<?php $__env->startSection('title', 'Admin || Edit Presensi'); ?>

<?php $__env->startSection('admincontent'); ?>
    <div class="page-title-box">
    </div>
    <!-- end page-title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h3 class="mt-0 header-title">Edit Presensi</h3>
                    <p class="sub-title">
                    </p>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <button type="button" class="close text-danger" data-dismiss="alert" aria-label="Close">
                                <span class="text-success" aria-hidden="true">&times;</span>
                            </button>
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible" role="alert">
                            <button type="button" class="close text-danger" data-dismiss="alert" aria-label="Close">
                                <span class="text-danger" aria-hidden="true">&times;</span>
                            </button>
                            <p class="mb-0"><strong>Maaf, terjadi kesalahan!</strong></p>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="mt-0 mb-1">- <?php echo e($error); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>


                    <form method="POST" action="<?php echo e(route('admin.presensikehadirans.updatepresensikehadiran')); ?>"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <div class="form-group col-md-6">
                                <input type="hidden" name="tanggalPresensi" value="<?php echo e($tanggalPresensi); ?>">
                                <h3>Tanggal Presensi : <?php echo e($tanggalPresensiTeks); ?></h3>
                            </div>
                            <div class="form-group col-md-6 text-right">
                                <button class="btn btn-info waves-effect waves-light mt-2" type="submit">
                                    Edit Presensi</button>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="form-group col-md-12">
                                <div>
                                    <table id="tabelDaftarPresensiKaryawan"
                                        class="table table-bordered dt-responsive nowrap text-center table-striped w-100"
                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>Nama Karyawan</th>
                                                <th>Tanggal Presensi</th>
                                                <th>Keterangan</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php
                                                $counter = 0;
                                                $arrKeterangan = ['hadir', 'sakit', 'izin', 'absen'];
                                                $arrKeteranganTolak = ['absen', 'hadir'];
                                                $arrStatusIzin = ['belum', 'konfirmasi', 'tolak'];
                                                $arrStatus = ['belum', 'konfirmasi'];

                                            ?>

                                            <?php $__currentLoopData = $arrObjectPresensiKehadiran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $presensi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr id="tr_<?php echo e($presensi->id); ?>">
                                                    <td><?php echo e($presensi->karyawan->nama); ?></td>
                                                    <td><?php echo e($tanggalPresensiTeks); ?></td>


                                                    <?php if($presensi->keterangan != 'izin' && $presensi->keterangan != 'sakit'): ?>
                                                        <input type="hidden" value="<?php echo e($presensi->karyawan->id); ?>"
                                                            name="daftarNamaKaryawan[]">
                                                        <td>
                                                            <div class="col-md-12">
                                                                <select name="keteranganPresensi[]"
                                                                    idKaryawan = "<?php echo e($presensi->karyawan->id); ?>"
                                                                    id="keteranganPresensiSelect"
                                                                    class="form-control keteranganPresensiSelect"
                                                                    aria-label="Default select example" required>
                                                                    <?php if(in_array($presensi->karyawan->id, $idUnikKaryawanYangIzinDitolak)): ?>
                                                                        <?php $__currentLoopData = $arrKeteranganTolak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($presensi->keterangan == $k): ?>
                                                                                <option selected
                                                                                    value="<?php echo e($k); ?>">
                                                                                    <?php echo e(strtoupper($k)); ?></option>
                                                                            <?php else: ?>
                                                                                <option value="<?php echo e($k); ?>">
                                                                                    <?php echo e(strtoupper($k)); ?></option>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <option disabled class="text-danger" value="tolak">
                                                                            SAKIT - ditolak</option>
                                                                        <option disabled class="text-danger" value="tolak">
                                                                            IZIN - ditolak</option>
                                                                    <?php else: ?>
                                                                        <?php $__currentLoopData = $arrKeterangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($presensi->keterangan == $k): ?>
                                                                                <option selected
                                                                                    value="<?php echo e($k); ?>">
                                                                                    <?php echo e(strtoupper($k)); ?></option>
                                                                            <?php else: ?>
                                                                                <option value="<?php echo e($k); ?>">
                                                                                    <?php echo e(strtoupper($k)); ?></option>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                </select>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="col-md-12">
                                                                <select name="statusPresensi[]"
                                                                    id="statusPresensiSelect_<?php echo e($presensi->karyawan->id); ?>"
                                                                    class="form-control statusPresensiSelect"
                                                                    aria-label="Default select example" required>
                                                                    <?php $__currentLoopData = $arrStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($presensi->status == $s): ?>
                                                                            <option selected value="<?php echo e($s); ?>">
                                                                                <?php echo e($s); ?>

                                                                            </option>
                                                                        <?php else: ?>
                                                                            <option value="<?php echo e($s); ?>">
                                                                                <?php echo e($s); ?>

                                                                            </option>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>

                                                        </td>
                                                        <?php
                                                            $counter++;
                                                        ?>
                                                    <?php else: ?>
                                                        

                                                        <?php if($presensi->status == 'konfirmasi'): ?>
                                                            <input type="hidden" value="<?php echo e($presensi->karyawan->id); ?>"
                                                                name="daftarNamaKaryawan[]">
                                                            <td>
                                                                <div class="col-md-12">
                                                                    <select name="keteranganPresensi[]"
                                                                        idKaryawan = "<?php echo e($presensi->karyawan->id); ?>"
                                                                        id="keteranganPresensiSelect"
                                                                        class="form-control keteranganPresensiSelect"
                                                                        aria-label="Default select example" required>
                                                                        <?php $__currentLoopData = $arrKeterangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($presensi->keterangan == $k): ?>
                                                                                <option selected
                                                                                    value="<?php echo e($k); ?>">
                                                                                    <?php echo e(strtoupper($k)); ?></option>
                                                                            <?php else: ?>
                                                                                <option value="<?php echo e($k); ?>">
                                                                                    <?php echo e(strtoupper($k)); ?></option>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                    </select>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="col-md-12">
                                                                    <select name="statusPresensi[]"
                                                                        id="statusPresensiSelect_<?php echo e($presensi->karyawan->id); ?>"
                                                                        class="form-control statusPresensiSelect"
                                                                        aria-label="Default select example" required>
                                                                        <?php $__currentLoopData = $arrStatusIzin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($presensi->status == $s): ?>
                                                                                <option selected
                                                                                    value="<?php echo e($s); ?>">
                                                                                    <?php echo e($s); ?>

                                                                                </option>
                                                                            <?php else: ?>
                                                                                <option value="<?php echo e($s); ?>">
                                                                                    <?php echo e($s); ?>

                                                                                </option>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </div>

                                                            </td>
                                                            <?php
                                                                $counter++;
                                                            ?>
                                                        <?php elseif($presensi->status == 'tolak'): ?>
                                                            <input type="hidden" value="<?php echo e($presensi->karyawan->id); ?>"
                                                                name="daftarNamaKaryawan[]">
                                                            <td>
                                                                <div class="col-md-12">
                                                                    <select name="keteranganPresensi[]"
                                                                        idKaryawan = "<?php echo e($presensi->karyawan->id); ?>"
                                                                        id="keteranganPresensiSelect"
                                                                        class="form-control keteranganPresensiSelect"
                                                                        aria-label="Default select example" required>
                                                                        <?php $__currentLoopData = $arrKeteranganTolak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($presensi->keterangan == $k): ?>
                                                                                <option selected
                                                                                    value="<?php echo e($k); ?>">
                                                                                    <?php echo e(strtoupper($k)); ?></option>
                                                                            <?php else: ?>
                                                                                <option value="<?php echo e($k); ?>">
                                                                                    <?php echo e(strtoupper($k)); ?></option>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <option disabled class="text-danger" value="tolak">
                                                                            SAKIT - ditolak</option>
                                                                        <option disabled class="text-danger" value="tolak">
                                                                            IZIN - ditolak</option>

                                                                    </select>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="col-md-12">
                                                                    <select name="statusPresensi[]"
                                                                        id="statusPresensiSelect_<?php echo e($presensi->karyawan->id); ?>"
                                                                        class="form-control statusPresensiSelect"
                                                                        aria-label="Default select example" required>
                                                                        <?php $__currentLoopData = $arrStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($presensi->status == $s): ?>
                                                                                <option selected
                                                                                    value="<?php echo e($s); ?>">
                                                                                    <?php echo e($s); ?>

                                                                                </option>
                                                                            <?php else: ?>
                                                                                <option value="<?php echo e($s); ?>">
                                                                                    <?php echo e($s); ?>

                                                                                </option>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </div>

                                                            </td>
                                                            <?php
                                                                $counter++;
                                                            ?>
                                                        <?php else: ?>
                                                            <input type="hidden" value="<?php echo e($presensi->karyawan->id); ?>"
                                                                name="daftarNamaKaryawan[]">
                                                            <td>
                                                                <div class="col-md-12">
                                                                    <select name="keteranganPresensi[]"
                                                                        idKaryawan = "<?php echo e($presensi->karyawan->id); ?>"
                                                                        id="keteranganPresensiSelect"
                                                                        class="form-control keteranganPresensiSelect"
                                                                        aria-label="Default select example" required>
                                                                        <?php $__currentLoopData = $arrKeterangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($presensi->keterangan == $k): ?>
                                                                                <option selected
                                                                                    value="<?php echo e($k); ?>">
                                                                                    <?php echo e(strtoupper($k)); ?></option>
                                                                            <?php else: ?>
                                                                                <option value="<?php echo e($k); ?>">
                                                                                    <?php echo e(strtoupper($k)); ?></option>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                    </select>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="col-md-12">
                                                                    <select name="statusPresensi[]"
                                                                        id="statusPresensiSelect_<?php echo e($presensi->karyawan->id); ?>"
                                                                        class="form-control statusPresensiSelect"
                                                                        aria-label="Default select example" required>
                                                                        <?php $__currentLoopData = $arrStatusIzin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($presensi->status == $s): ?>
                                                                                <option selected
                                                                                    value="<?php echo e($s); ?>">
                                                                                    <?php echo e($s); ?>

                                                                                </option>
                                                                            <?php else: ?>
                                                                                <option value="<?php echo e($s); ?>">
                                                                                    <?php echo e($s); ?>

                                                                                </option>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </div>

                                                            </td>
                                                            <?php
                                                                $counter++;
                                                            ?>
                                                            
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </form>


                </div>
            </div>
        </div>
        <!-- end col -->
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        $(document).ready(function() {
            // $('#tabelDaftarPresensiKaryawan').DataTable({

            // });

        });
        $('body').on('change', '.keteranganPresensiSelect', function() {
            var valueKeterangan = $(this).val();
            var idKaryawan = $(this).attr("idKaryawan");

            if (valueKeterangan == "izin" || valueKeterangan == "sakit") {
                $("#statusPresensiSelect_" + idKaryawan + " option[value='tolak']").remove();
                $("#statusPresensiSelect_" + idKaryawan).append("<option value='tolak'>tolak</option>");
            } else {
                $("#statusPresensiSelect_" + idKaryawan + " option[value='tolak']").remove();
            }

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\salon_ta\160420050_serenity\resources\views/admin/karyawan/presensikehadiran/editpresensi.blade.php ENDPATH**/ ?>