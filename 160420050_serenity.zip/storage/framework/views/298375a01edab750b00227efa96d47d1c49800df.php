

<?php $__env->startSection('title', 'Admin || Buka Presensi'); ?>

<?php $__env->startSection('admincontent'); ?>
    <div class="page-title-box">
    </div>
    <!-- end page-title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h3 class="mt-0 header-title">Buka Presensi</h3>
                    <p class="sub-title">
                    </p>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <button type="button" class="close text-danger" data-dismiss="alert" aria-label="Close">
                                <span class="text-success" aria-hidden="true">&times;</span>
                            </button>
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible" role="alert">
                            <button type="button" class="close text-danger" data-dismiss="alert" aria-label="Close">
                                <span class="text-danger" aria-hidden="true">&times;</span>
                            </button>
                            <p class="mb-0"><strong>Maaf, terjadi kesalahan!</strong></p>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="mt-0 mb-1">- <?php echo e($error); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>


                    <form method="POST" action="<?php echo e(route('presensikehadirans.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <div class="form-group col-md-6">
                                <h3>Tanggal Presensi : <?php echo e($tanggalHariIniTeks); ?></h3>
                                <h6>Dibuka pada pukul <span class="text-danger"><?php echo e(date('H:i')); ?></span></h6>
                                <input type="hidden" name="waktuBukaPresensi" value="<?php echo e(date('H:i')); ?>">
                            </div>
                            <div class="form-group col-md-6 text-right">
                                <button class="btn btn-info waves-effect waves-light mt-2" type="submit">
                                    Konfirmasi Buka Presensi</button>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="form-group col-md-12">
                                <div>
                                    <table id="tabelDaftarPresensiKaryawan"
                                        class="table table-bordered dt-responsive nowrap text-center table-striped w-100"
                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>Nama Karyawan</th>
                                                <th>Tanggal Presensi</th>
                                                <th>Keterangan</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php
                                                $counter = 0;
                                                $arrKeterangan = ['absen', 'hadir', 'sakit', 'izin'];
                                                $arrKeteranganTolak = ['absen', 'hadir'];
                                                $arrStatusIzin = ['belum', 'konfirmasi', 'tolak'];
                                                $arrStatus = ['belum', 'konfirmasi'];

                                            ?>

                                            <?php $__currentLoopData = $karyawans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $karyawan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr id="tr_<?php echo e($karyawan->id); ?>">
                                                    <td><?php echo e($karyawan->nama); ?></td>
                                                    <td><?php echo e($tanggalHariIniTeks); ?></td>

                                                    <?php if(!in_array($karyawan->id, $idKaryawansIzin)): ?>
                                                        <input type="hidden" value="<?php echo e($karyawan->id); ?>"
                                                            name="daftarNamaKaryawan[]">
                                                        <td>
                                                            <div class="col-md-12">
                                                                <?php
                                                                    $presensi = $arrObjectPresensiHariIniTanpaIzin->firstWhere('karyawan_id', $karyawan->id);
                                                                ?>
                                                                <?php if($presensi != null): ?>
                                                                    <input type="hidden" name="keteranganPresensi[]"
                                                                        value="<?php echo e($presensi->keterangan); ?>">
                                                                    <?php echo e(strtoupper($presensi->keterangan)); ?>

                                                                <?php else: ?>
                                                                    <input type="hidden" name="keteranganPresensi[]"
                                                                        value="absen">
                                                                    <span class="text-danger">ABSEN</span>
                                                                <?php endif; ?>
                                                                
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <span class="text-warning h6 font-weight-bold">Akan
                                                                Dikonfirmasi</span>
                                                            <input type="hidden" name="statusPresensi[]" value="belum">
                                                            

                                                        </td>
                                                        <?php
                                                            $counter++;
                                                        ?>
                                                    <?php else: ?>
                                                        <?php
                                                            $presensiIzinKaryawanTerpilih = $daftarIzinPresensiHariIni->firstWhere('karyawan_id', $karyawan->id);
                                                        ?>

                                                        <?php if($presensiIzinKaryawanTerpilih->status == 'konfirmasi'): ?>
                                                            <td style="font-size: 1.3em">
                                                                <?php if($presensiIzinKaryawanTerpilih->keterangan == 'izin'): ?>
                                                                    <span class="font-weight-bold text-warning">IZIN</span>
                                                                <?php else: ?>
                                                                    <span class="font-weight-bold text-info">SAKIT</span>
                                                                <?php endif; ?>

                                                            </td>
                                                            <td>
                                                                <span class="text-success font-weight-bold">Telah
                                                                    Dikonfirmasi</span>
                                                            </td>
                                                        <?php elseif($presensiIzinKaryawanTerpilih->status == 'tolak'): ?>
                                                            <input type="hidden" value="<?php echo e($karyawan->id); ?>"
                                                                name="daftarNamaKaryawan[]">
                                                            <td>
                                                                <div class="col-md-12">
                                                                    <select name="keteranganPresensi[]"
                                                                        idKaryawan = "<?php echo e($karyawan->id); ?>"
                                                                        id="keteranganPresensiSelect"
                                                                        class="form-control keteranganPresensiSelect"
                                                                        aria-label="Default select example" required>
                                                                        <?php if(old('keteranganPresensi') != null): ?>
                                                                            <?php $__currentLoopData = $arrKeteranganTolak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php if(old('keteranganPresensi')[$counter] == $k): ?>
                                                                                    <option selected
                                                                                        value="<?php echo e($k); ?>">
                                                                                        <?php echo e(strtoupper($k)); ?>

                                                                                    </option>
                                                                                <?php else: ?>
                                                                                    <option value="<?php echo e($k); ?>">
                                                                                        <?php echo e(strtoupper($k)); ?>

                                                                                    </option>
                                                                                <?php endif; ?>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php else: ?>
                                                                            <option value="absen">ABSEN</option>
                                                                            <option value="hadir">HADIR</option>
                                                                        <?php endif; ?>

                                                                    </select>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="col-md-12">
                                                                    <?php if(old('keteranganPresensi') != null): ?>
                                                                        <?php if(old('keteranganPresensi')[$counter] == 'izin' || old('keteranganPresensi')[$counter] == 'sakit'): ?>
                                                                            <?php if(old('statusPresensi') != null): ?>
                                                                                <select name="statusPresensi[]"
                                                                                    id="statusPresensiSelect_<?php echo e($karyawan->id); ?>"
                                                                                    class="form-control statusPresensiSelect"
                                                                                    aria-label="Default select example"
                                                                                    required>
                                                                                    <?php $__currentLoopData = $arrStatusIzin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <?php if(old('statusPresensi')[$counter] == $s): ?>
                                                                                            <option selected
                                                                                                value="<?php echo e($s); ?>">
                                                                                                <?php echo e($s); ?>

                                                                                            </option>
                                                                                        <?php else: ?>
                                                                                            <option
                                                                                                value="<?php echo e($s); ?>">
                                                                                                <?php echo e($s); ?>

                                                                                            </option>
                                                                                        <?php endif; ?>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                </select>
                                                                            <?php else: ?>
                                                                                <select name="statusPresensi[]"
                                                                                    id="statusPresensiSelect_<?php echo e($karyawan->id); ?>"
                                                                                    class="form-control statusPresensiSelect"
                                                                                    aria-label="Default select example"
                                                                                    required>
                                                                                    <option value="belum">belum
                                                                                    </option>
                                                                                    <option value="konfirmasi">konfimasi
                                                                                    </option>
                                                                                    <option value="tolak">tolak
                                                                                    </option>
                                                                                </select>
                                                                            <?php endif; ?>
                                                                        <?php else: ?>
                                                                            <?php if(old('statusPresensi') != null): ?>
                                                                                <select name="statusPresensi[]"
                                                                                    id="statusPresensiSelect_<?php echo e($karyawan->id); ?>"
                                                                                    class="form-control statusPresensiSelect"
                                                                                    aria-label="Default select example"
                                                                                    required>
                                                                                    <?php $__currentLoopData = $arrStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <?php if(old('statusPresensi')[$counter] == $s): ?>
                                                                                            <option selected
                                                                                                value="<?php echo e($s); ?>">
                                                                                                <?php echo e($s); ?>

                                                                                            </option>
                                                                                        <?php else: ?>
                                                                                            <option
                                                                                                value="<?php echo e($s); ?>">
                                                                                                <?php echo e($s); ?>

                                                                                            </option>
                                                                                        <?php endif; ?>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                </select>
                                                                            <?php else: ?>
                                                                                <select name="statusPresensi[]"
                                                                                    id="statusPresensiSelect_<?php echo e($karyawan->id); ?>"
                                                                                    class="form-control statusPresensiSelect"
                                                                                    aria-label="Default select example"
                                                                                    required>
                                                                                    <option value="belum">belum
                                                                                    </option>
                                                                                    <option value="konfirmasi">konfirmasi
                                                                                    </option>

                                                                                </select>
                                                                            <?php endif; ?>
                                                                        <?php endif; ?>
                                                                    <?php else: ?>
                                                                        <select name="statusPresensi[]"
                                                                            id="statusPresensiSelect_<?php echo e($karyawan->id); ?>"
                                                                            class="form-control statusPresensiSelect"
                                                                            aria-label="Default select example" required>
                                                                            <option value="belum">belum
                                                                            </option>
                                                                            <option value="konfirmasi">konfirmasi
                                                                            </option>
                                                                        </select>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </td>
                                                            <?php
                                                                $counter++;
                                                            ?>
                                                        <?php else: ?>
                                                            <input type="hidden" value="<?php echo e($karyawan->id); ?>"
                                                                name="daftarNamaKaryawan[]">

                                                            <td style="font-size: 1.3em">
                                                                <?php if($presensiIzinKaryawanTerpilih->keterangan == 'izin'): ?>
                                                                    <span class="font-weight-bold text-warning">IZIN</span>
                                                                <?php else: ?>
                                                                    <span class="font-weight-bold text-info">SAKIT</span>
                                                                <?php endif; ?>

                                                            </td>
                                                            <?php if($presensiIzinKaryawanTerpilih->keterangan == 'izin'): ?>
                                                                <input type="hidden" value="izin"
                                                                    name="keteranganPresensi[]">
                                                            <?php else: ?>
                                                                <input type="hidden" value="sakit"
                                                                    name="keteranganPresensi[]">
                                                            <?php endif; ?>


                                                            <td>
                                                                <div class="col-md-12">
                                                                    <?php if(old('keteranganPresensi') != null): ?>
                                                                        <?php if(old('statusPresensi') != null): ?>
                                                                            <select name="statusPresensi[]"
                                                                                id="statusPresensiSelect_<?php echo e($karyawan->id); ?>"
                                                                                class="form-control statusPresensiSelect"
                                                                                aria-label="Default select example"
                                                                                required>
                                                                                <?php $__currentLoopData = $arrStatusIzin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php if(old('statusPresensi')[$counter] == $s): ?>
                                                                                        <option selected
                                                                                            value="<?php echo e($s); ?>">
                                                                                            <?php echo e($s); ?>

                                                                                        </option>
                                                                                    <?php else: ?>
                                                                                        <option
                                                                                            value="<?php echo e($s); ?>">
                                                                                            <?php echo e($s); ?>

                                                                                        </option>
                                                                                    <?php endif; ?>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </select>
                                                                        <?php else: ?>
                                                                            <select name="statusPresensi[]"
                                                                                id="statusPresensiSelect_<?php echo e($karyawan->id); ?>"
                                                                                class="form-control statusPresensiSelect"
                                                                                aria-label="Default select example"
                                                                                required>
                                                                                <option value="belum">belum
                                                                                </option>
                                                                                <option value="konfirmasi">konfimasi
                                                                                </option>

                                                                                <option value="tolak">tolak
                                                                                </option>
                                                                            </select>
                                                                        <?php endif; ?>
                                                                    <?php else: ?>
                                                                        <select name="statusPresensi[]"
                                                                            id="statusPresensiSelect_<?php echo e($karyawan->id); ?>"
                                                                            class="form-control statusPresensiSelect"
                                                                            aria-label="Default select example" required>
                                                                            <option value="belum">belum
                                                                            </option>
                                                                            <option value="konfirmasi">konfirmasi
                                                                            </option>
                                                                            <option value="tolak">tolak
                                                                            </option>
                                                                        </select>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </td>
                                                            <?php
                                                                $counter++;
                                                            ?>
                                                            
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </form>


                </div>
            </div>
        </div>
        <!-- end col -->
    </div>

    <div id="modalDetailKaryawan" class="modal fade bs-example-modal-center" tabindex="-1" role="dialog"
        aria-labelledby="mySmallModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" style="max-width: 600px;">
            <div class="modal-content ">
                <div class="modal-header">
                    <h5 class="modal-title mt-0" id="modalNamaKaryawan">Detail Karyawan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="contentDetailKaryawan">
                    <div class="text-center">
                        <div class="spinner-border text-info" role="status">
                            <span class="sr-only">Loading...</span>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">Tutup</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        $(document).ready(function() {
            // $('#tabelDaftarPresensiKaryawan').DataTable({

            // });

        });

        
        $('.btnHapusKaryawan').on('click', function() {

            var idKaryawan = $(this).attr("idKaryawan");
            var namaKaryawan = $(this).attr('namaKaryawan');
            var routeUrl = $(this).attr('routeUrl');
            $("#modalNamaKaryawanDelete").text("Konfirmasi Penghapusan Karyawan " + namaKaryawan);
            $("#modalBodyHapusKaryawan").html("<h6>Apakah Anda yakin untuk menghapus perawatan " + namaKaryawan +
                "?</h6>")
            $("#formDeleteKaryawan").attr("action", routeUrl);
        });

        $('body').on('change', '.keteranganPresensiSelect', function() {
            var valueKeterangan = $(this).val();
            var idKaryawan = $(this).attr("idKaryawan");

            if (valueKeterangan == "izin") {
                $("#statusPresensiSelect_" + idKaryawan + " option[value='tolak']").remove();
                $("#statusPresensiSelect_" + idKaryawan).append("<option value='tolak'>tolak</option>");
            } else {
                $("#statusPresensiSelect_" + idKaryawan + " option[value='tolak']").remove();
            }

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\salon_ta\160420050_serenity\resources\views/admin/karyawan/presensikehadiran/bukapresensi1.blade.php ENDPATH**/ ?>