<div>
    <table id="tabelDaftarDetailKomisiKaryawan" class="table table-bordered dt-responsive nowrap text-center w-100"
        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
        <thead>
            <tr>
                <th>Nomor Nota</th>
                <th hidden>tanggalHidden</th>
                <th>Tanggal Perawatan</th>
                <th>Nama Perawatan</th>
                <th>Persentase Komisi (%)</th>
                <th>Harga pada Nota Perawatan (Rp)</th>
                <th>Total Komisi (Rp)</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $daftarPenjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($p->penjualan->nomor_nota); ?></td>
                    <td hidden><?php echo e($p->penjualan->tanggal_penjualan); ?></td>
                    <td><?php echo e(date('d-m-Y', strtotime($p->penjualan->tanggal_penjualan))); ?></td>
                    <td>
                        <?php echo e($p->perawatan->nama); ?>

                    </td>

                    <td>
                        <?php echo e($p->perawatan->komisi); ?>

                    </td>

                    <td>
                        <?php echo e(number_format($p->harga, 2, ',', '.')); ?>

                    </td>

                    <td>
                        <?php echo e(number_format(($p->harga * $p->perawatan->komisi) / 100, 2, ',', '.')); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\salon_ta\160420050_serenity\resources\views/admin/karyawan/komisikaryawan/detailkomisikaryawan.blade.php ENDPATH**/ ?>