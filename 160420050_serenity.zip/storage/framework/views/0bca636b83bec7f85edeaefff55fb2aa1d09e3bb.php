<table id="tabelDaftarProdukMerek" class="table table-striped table-bordered dt-responsive wrap text-center"
    style="border-collapse: collapse; border-spacing: 0; width: 100%;">
    <thead>
        <tr>
            <th>Kode Produk</th>
            <th>Nama</th>
            <th>Harga Beli(Rp)</th>
            <th>harga Jual (RP)</th>
            <th>Kategori</th>
            <th>Kondisi</th>
            <th>Deskripsi</th>
        </tr>
    </thead>

    <tbody>
        <?php $__currentLoopData = $daftarProdukMerek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="tr_<?php echo e($p->id); ?>">
                <td><?php echo e($p->kode_produk); ?></td>
                <td><?php echo e($p->nama); ?></td>
                <td><?php echo e(number_format($p->harga_beli, 2, ',', '.')); ?></td>
                <td><?php echo e(number_format($p->harga_jual, 2, ',', '.')); ?></td>
                <td><?php echo e($p->kategori->nama); ?></td>
                <td class="text-left">
                    <ul>
                        <?php $__currentLoopData = $p->kondisis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kondisi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($kondisi->keterangan); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </td>

                <td><?php echo e($p->deskripsi); ?></td>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\salon_ta\160420050_serenity\resources\views/admin/produk/merekproduk/daftarprodukmerek.blade.php ENDPATH**/ ?>