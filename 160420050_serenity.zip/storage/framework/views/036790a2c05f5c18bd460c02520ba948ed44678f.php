<?php if(count($slotJams) == 0): ?>
    <option selected disabled>Tidak Ada Slot Jam Tersedia</option>
<?php else: ?>
    <option selected disabled>Pilih Slot Jam</option>
    <?php $__currentLoopData = $slotJams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slotJam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($slotJam->id); ?>">
            <?php echo e($slotJam->jam); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\salon_ta\serenity\resources\views/admin/reservasi/optionslotjam.blade.php ENDPATH**/ ?>